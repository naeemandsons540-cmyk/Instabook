import React, { useState } from 'react';
import { collection, doc, setDoc } from 'firebase/firestore';
import { db, auth, OperationType, handleFirestoreError } from '../firebase';
import { uploadImage } from '../utils/image';
import { Image, Video, X, Globe, User, ShieldAlert } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { UserProfile } from '../types';

interface CreatePostProps {
  currentUserProfile: UserProfile | null;
  onPostCreated: () => void;
  onClose: () => void;
}

export function CreatePostModal({ currentUserProfile, onPostCreated, onClose }: CreatePostProps) {
  const [content, setContent] = useState('');
  const [videoURL, setVideoURL] = useState('');
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [showVideoInput, setShowVideoInput] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (!file.type.startsWith('image/')) {
        setErrorMsg('Invalid file type. Please select an image.');
        return;
      }
      setImageFile(file);
      const url = URL.createObjectURL(file);
      setImagePreview(url);
    }
  };

  const removeSelectedImage = () => {
    setImageFile(null);
    setImagePreview(null);
  };

  const handleCreatePost = async (e: React.FormEvent) => {
    e.preventDefault();

    const textEmpty = content.trim().length === 0;
    const noImg = !imageFile;
    const noVideo = videoURL.trim().length === 0;

    if (textEmpty && noImg && noVideo) {
      setErrorMsg('Posts must contain at least one of: text, image, or video link.');
      return;
    }

    setLoading(true);
    setErrorMsg(null);

    const user = auth.currentUser;
    if (!user || !currentUserProfile) {
      setErrorMsg('You must be logged in to create posts.');
      setLoading(false);
      return;
    }

    try {
      let finalImageURL = '';

      // 1. Process and upload image to ImgBB or Base64 fallback if user attached any
      if (imageFile) {
        finalImageURL = await uploadImage(imageFile);
      }

      // 2. Prepare payload structure
      // Pre-generating unique post ID using doc(collection(...)) to ensure we satisfy isValidPost(incoming())
      const pathForPost = 'posts';
      const postsCol = collection(db, pathForPost);
      const docRef = doc(postsCol);
      
      const payload: any = {
        id: docRef.id,
        authorId: user.uid,
        authorName: currentUserProfile.name || user.displayName || 'Social User',
        authorPhotoURL: currentUserProfile.photoURL || user.photoURL || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&h=150',
        authorUsername: currentUserProfile.username || user.email?.split('@')[0] || 'user',
        likesCount: 0,
        commentsCount: 0,
        createdAt: new Date(), // JS Date translates cleanly to Timestamp
      };

      if (content.trim()) payload.content = content.trim();
      if (finalImageURL) payload.imageURL = finalImageURL;
      if (videoURL.trim()) payload.videoURL = videoURL.trim();

      // Create doc with schema complete inside single write
      await setDoc(docRef, payload);

      onPostCreated();
    } catch (err: any) {
      console.error(err);
      handleFirestoreError(err, OperationType.WRITE, 'posts');
      setErrorMsg(err.message || 'Failed creating new post.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 font-sans select-none" id="create_post_overlay">
      <motion.div
        initial={{ y: '100%' }}
        animate={{ y: 0 }}
        exit={{ y: '100%' }}
        className="bg-white rounded-t-3xl sm:rounded-3xl w-full max-w-lg p-5 border border-slate-100 flex flex-col max-h-[92vh] sm:max-h-[85vh] shadow-2xl"
        id="create_post_modal_box"
      >
        {/* Header Specs */}
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <button id="close_create_post_x" onClick={onClose} className="p-1.5 hover:bg-slate-100 rounded-full transition cursor-pointer">
            <X className="w-5 h-5 text-slate-500" />
          </button>
          <span className="font-bold text-slate-800 text-sm">Create Post</span>
          <button
            id="modal_post_submit_btn"
            onClick={handleCreatePost}
            disabled={loading}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-700 active:bg-blue-800 disabled:opacity-50 transition text-white text-xs font-bold rounded-xl shadow-md cursor-pointer"
          >
            {loading ? 'Posting...' : 'Post'}
          </button>
        </div>

        {/* Content body input areas scrolled */}
        <div className="flex-1 overflow-y-auto py-4 space-y-4 pr-1">
          {/* User profile identifier */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full overflow-hidden bg-slate-100 border border-slate-100">
              {currentUserProfile?.photoURL ? (
                <img src={currentUserProfile.photoURL} alt="Me" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
              ) : (
                <User className="w-5 h-5 text-slate-400" />
              )}
            </div>
            <div>
              <div className="font-bold text-slate-800 text-sm leading-none">{currentUserProfile?.name}</div>
              <div className="flex items-center gap-1 text-[10px] text-slate-400 mt-1.5 font-bold bg-slate-100 px-1.5 py-0.5 rounded-full w-max">
                <Globe className="w-3 h-3" />
                <span>Public</span>
              </div>
            </div>
          </div>

          {/* Text Area Content */}
          <textarea
            id="create_post_textarea"
            placeholder="What's on your mind?"
            value={content}
            onChange={(e) => setContent(e.target.value)}
            disabled={loading}
            className="w-full min-h-[120px] bg-transparent outline-none border-none text-slate-900 text-sm leading-relaxed resize-none placeholder-slate-400"
          />

          {/* Image Selected Previews */}
          {imagePreview && (
            <div className="relative rounded-2xl overflow-hidden bg-slate-50 border border-slate-200" id="post_editor_image_box">
              <img src={imagePreview} alt="Selected to Post" className="w-full h-56 object-cover" referrerPolicy="no-referrer" />
              <button
                id="remove_attached_img_btn"
                type="button"
                onClick={removeSelectedImage}
                className="absolute top-2.5 right-2.5 p-1.5 bg-black/60 hover:bg-black/80 rounded-full text-white transition cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* Video Attachment Details */}
          {showVideoInput && (
            <div className="bg-slate-50/70 border border-slate-200/60 p-3 rounded-2xl flex flex-col gap-2 relative">
              <label className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Embed Video link (YouTube, Google Drive)</label>
              <input
                id="video_attachment_link_input"
                type="url"
                placeholder="https://www.youtube.com/watch?v=..."
                value={videoURL}
                onChange={(e) => setVideoURL(e.target.value)}
                disabled={loading}
                className="w-full bg-white border border-slate-200 px-3 py-2 rounded-xl text-xs text-slate-800 outline-none focus:border-blue-500 transition"
              />
              <button
                id="close_video_input_btn"
                onClick={() => {
                  setVideoURL('');
                  setShowVideoInput(false);
                }}
                className="absolute top-2 right-2 p-1 text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {errorMsg && (
            <div className="p-3 bg-rose-50 border border-rose-100 rounded-xl flex items-start gap-2 text-rose-700 text-xs shadow-sm" id="post_create_error">
              <ShieldAlert className="w-4 h-4 mt-0.5 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}
        </div>

        {/* Action Tray triggers at standard footer */}
        <div className="border-t border-slate-100 pt-3 flex items-center justify-between">
          <span className="text-xs font-bold text-slate-400">Add content to post</span>
          <div className="flex gap-2">
            {/* Image attachment button */}
            <label className="p-2.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-600 rounded-2xl transition cursor-pointer flex items-center justify-center shrink-0">
              <Image className="w-5 h-5 stroke-[2.2]" />
              <input
                id="attach_img_input"
                type="file"
                accept="image/*"
                onChange={handleImageSelect}
                disabled={loading}
                className="hidden"
              />
            </label>

            {/* Video Link trigger */}
            <button
              id="trigger_video_input_btn"
              onClick={() => setShowVideoInput(true)}
              disabled={loading}
              className="p-2.5 bg-red-50 hover:bg-red-100 text-red-600 rounded-2xl transition cursor-pointer flex items-center justify-center shrink-0"
            >
              <Video className="w-5 h-5 stroke-[2.2]" />
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
