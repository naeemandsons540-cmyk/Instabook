import { Home, Search, Bell, MessageSquare, User } from 'lucide-react';
import { ViewType } from '../types';

interface BottomNavProps {
  currentView: ViewType;
  onChangeView: (view: ViewType) => void;
  unreadNotificationsCount?: number;
  unreadChatsCount?: number;
}

export function BottomNav({
  currentView,
  onChangeView,
  unreadNotificationsCount = 0,
  unreadChatsCount = 0,
}: BottomNavProps) {
  const navItems = [
    { id: 'feed', label: 'Feed', icon: Home, badge: 0 },
    { id: 'search', label: 'Search', icon: Search, badge: 0 },
    { id: 'messages', label: 'Chats', icon: MessageSquare, badge: unreadChatsCount },
    { id: 'notifications', label: 'Alerts', icon: Bell, badge: unreadNotificationsCount },
    { id: 'profile', label: 'Profile', icon: User, badge: 0 },
  ];

  return (
    <nav
      className="fixed bottom-0 left-0 right-0 h-16 bg-white border-t border-slate-100 flex items-center justify-around px-2 pb-safe z-40 select-none shadow-[0_-4px_24px_rgba(148,163,184,0.04)] md:hidden"
      id="bottom_nav_bar"
    >
      {navItems.map((item) => {
        const Icon = item.icon;
        const isActive = currentView === item.id;
        return (
          <button
            key={item.id}
            id={`nav_btn_${item.id}`}
            onClick={() => onChangeView(item.id as ViewType)}
            className="flex flex-col items-center justify-center w-14 h-full relative group transition cursor-pointer"
          >
            <div
              className={`p-1.5 rounded-xl transition ${
                isActive
                  ? 'text-blue-600 bg-blue-50/70'
                  : 'text-slate-400 group-hover:text-slate-600 group-active:scale-95'
              }`}
            >
              <Icon className={`w-5 h-5 stroke-[2.2]`} />
            </div>

            {/* Notification Badges */}
            {item.badge > 0 && (
              <span
                id={`badge_${item.id}`}
                className="absolute top-2.5 right-2.5 min-w-4 h-4 bg-rose-500 text-white rounded-full text-[10px] font-bold px-1 flex items-center justify-center shadow-sm border border-white"
              >
                {item.badge}
              </span>
            )}

            <span
              className={`text-[9.5px] font-semibold mt-0.5 tracking-tight transition ${
                isActive ? 'text-blue-600 scale-102' : 'text-slate-400'
              }`}
            >
              {item.label}
            </span>
          </button>
        );
      })}
    </nav>
  );
}
