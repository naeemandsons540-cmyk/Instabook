import React from 'react';
import { Plus, User } from 'lucide-react';
import { Story, UserProfile } from '../types';

interface StoryBubbleProps {
  currentUserProfile: UserProfile | null;
  groupedStories: { authorId: string; stories: Story[] }[];
  onSelectStoryGroup: (index: number) => void;
  onUploadStory: (file: File) => void;
  isUploading: boolean;
}

export function StoryBubble({
  currentUserProfile,
  groupedStories,
  onSelectStoryGroup,
  onUploadStory,
  isUploading,
}: StoryBubbleProps) {

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onUploadStory(file);
    }
  };

  return (
    <div className="flex gap-2.5 overflow-x-auto pb-3 pt-1 px-4 scrollbar-none select-none" id="stories_row">
      {/* 1. Create Story Trigger Card */}
      <div 
        className="w-24 h-36 rounded-2xl relative bg-slate-100 flex flex-col shrink-0 overflow-hidden border border-slate-200/50 shadow-sm"
        id="story_builder_card"
      >
        <div className="flex-1 overflow-hidden bg-slate-200">
          {currentUserProfile?.photoURL ? (
            <img 
              src={currentUserProfile.photoURL} 
              alt="You" 
              className="w-full h-full object-cover transition duration-300 hover:scale-105" 
              referrerPolicy="no-referrer"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center">
              <User className="w-8 h-8 text-slate-400" />
            </div>
          )}
        </div>
        
        <label className="h-11 bg-white relative flex flex-col items-center justify-center cursor-pointer">
          <input 
            type="file" 
            accept="image/*" 
            onChange={handleFileChange} 
            disabled={isUploading}
            className="hidden" 
            id="story_file_uploader"
          />
          <span className="absolute -top-4 p-1.5 bg-blue-600 rounded-full text-white border-2 border-white shadow-md hover:bg-blue-700 transition shrink-0">
            {isUploading ? (
              <span className="w-3.5 h-3.5 block rounded-full border-2 border-white border-t-transparent animate-spin"></span>
            ) : (
              <Plus className="w-3.5 h-3.5 stroke-[3]" />
            )}
          </span>
          <span className="text-[10px] font-bold text-slate-800 mt-2">Create Story</span>
        </label>
      </div>

      {/* 2. Live Story Iterators */}
      {groupedStories.map((group, index) => {
        const firstStory = group.stories[0];
        if (!firstStory) return null;

        return (
          <div
            key={group.authorId}
            id={`story_card_${group.authorId}`}
            onClick={() => onSelectStoryGroup(index)}
            className="w-24 h-36 rounded-2xl relative shrink-0 overflow-hidden cursor-pointer shadow-sm border border-slate-200/50 group"
          >
            {/* Story Background Cover */}
            <img 
              src={firstStory.imageURL} 
              alt={firstStory.authorName} 
              className="w-full h-full object-cover transition duration-300 group-hover:scale-105 group-active:scale-98"
              referrerPolicy="no-referrer"
            />

            {/* Overlay Gradient */}
            <div className="absolute inset-0 bg-gradient-to-b from-black/35 via-transparent to-black/70 pointer-events-none" />

            {/* Author Avatar with blue border */}
            <div className="absolute top-2 left-2 w-8 h-8 rounded-full border-2 border-blue-500 overflow-hidden bg-slate-300">
              <img 
                src={firstStory.authorPhotoURL || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&h=150'} 
                alt="Avatar" 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>

            {/* Author Username display */}
            <div className="absolute bottom-2 left-2 right-2 text-white truncate font-bold text-[10px] leading-tight">
              {firstStory.authorUsername}
            </div>
          </div>
        );
      })}
    </div>
  );
}
