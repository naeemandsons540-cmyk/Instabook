import { useState, useEffect } from 'react';
import { collection, getDocs, onSnapshot } from 'firebase/firestore';
import { db } from '../firebase';
import { Post, UserProfile } from '../types';
import { Search, User, FileText, ArrowRight, Sparkles, Compass, HelpCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface SearchViewProps {
  onSelectPost: (postId: string) => void;
  onSelectUser: (userId: string) => void;
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  blockedUserIds?: string[];
}

// Calculate Age helper
function calculateAge(dobString: string): number {
  if (!dobString) return 0;
  try {
    const birthDate = new Date(dobString);
    const today = new Date();
    let age = today.getFullYear() - birthDate.getFullYear();
    const m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    return age > 0 ? age : 0;
  } catch (e) {
    return 0;
  }
}

export function SearchView({ onSelectPost, onSelectUser, searchQuery, setSearchQuery, blockedUserIds = [] }: SearchViewProps) {
  const [allUsers, setAllUsers] = useState<UserProfile[]>([]);
  const [loadingAllUsers, setLoadingAllUsers] = useState(true);
  const [debouncedQuery, setDebouncedQuery] = useState('');
  const [searching, setSearching] = useState(false);
  const [postsResults, setPostsResults] = useState<Post[]>([]);

  // 1. Subscribe to all active registered users in real-time
  useEffect(() => {
    const usersCol = collection(db, 'users');
    const unsub = onSnapshot(usersCol, (snapshot) => {
      const list: UserProfile[] = [];
      snapshot.forEach((doc) => {
        list.push({ uid: doc.id, ...doc.data() } as UserProfile);
      });
      setAllUsers(list);
      setLoadingAllUsers(false);
    }, (err) => {
      console.error('Error fetching active registered users:', err);
      setLoadingAllUsers(false);
    });

    return () => unsub();
  }, []);

  // 2. Debounce core search parameter changes
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedQuery(searchQuery.trim().toLowerCase());
    }, 350);
    return () => clearTimeout(timer);
  }, [searchQuery]);

  // 3. Search and stream matches in post content
  useEffect(() => {
    if (!debouncedQuery) {
      setPostsResults([]);
      return;
    }

    setSearching(true);
    const postsCol = collection(db, 'posts');
    const unsub = onSnapshot(postsCol, (snapshot) => {
      const list: Post[] = [];
      snapshot.forEach((doc) => {
        const pd = doc.data();
        const contentMatch = pd.content?.toLowerCase().includes(debouncedQuery);
        const authorBlocked = blockedUserIds.includes(pd.authorId);
        if (contentMatch && !authorBlocked) {
          list.push({ id: doc.id, ...pd } as Post);
        }
      });
      // Sort posts chronologically (latest first)
      list.sort((a, b) => {
        const tA = a.createdAt?.seconds || 0;
        const tB = b.createdAt?.seconds || 0;
        return tB - tA;
      });
      setPostsResults(list);
      setSearching(false);
    }, (err) => {
      console.error('Error loading matching posts sets:', err);
      setSearching(false);
    });

    return () => unsub();
  }, [debouncedQuery, blockedUserIds]);

  // 4. Client-side filter applied to live users subset
  const filteredUsers = allUsers.filter((usr) => {
    if (blockedUserIds.includes(usr.uid)) return false;
    if (!debouncedQuery) return true;
    return (
      usr.name?.toLowerCase().includes(debouncedQuery) ||
      usr.username?.toLowerCase().includes(debouncedQuery)
    );
  });

  return (
    <div className="min-h-screen bg-slate-50 pb-24 font-sans select-none" id="search_view_root">
      {/* Search Input Bar (sticky - visible on both mobile & desktop) */}
      <div className="bg-white border-b border-slate-100 p-4 sticky top-0 z-20 shadow-xs mb-6" id="search_bar_container">
        <div className="relative max-w-xl mx-auto w-full">
          <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 text-slate-400">
            <Search className="w-4 h-4" />
          </span>
          <input
            id="search_text_input_unified"
            type="search"
            placeholder="Search active users, usernames, or posts..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-full outline-none focus:bg-white focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 transition text-slate-800 text-xs sm:text-sm font-medium shadow-xs"
          />
        </div>
      </div>

      <main className="max-w-4xl mx-auto px-4 " id="search_results_container">
        {/* Loading Spinner */}
        {(loadingAllUsers || (searching && postsResults.length === 0)) && (
          <div className="flex flex-col items-center justify-center py-20 text-slate-400 gap-2" id="search_loading_box">
            <span className="w-6 h-6 rounded-full border-3 border-blue-500 border-t-transparent animate-spin"></span>
            <span className="text-[11px] font-semibold text-slate-400">Browsing registered database...</span>
          </div>
        )}

        {!loadingAllUsers && (
          <div className="space-y-8" id="explore_content_area">
            {/* Registered Users Section */}
            <div className="space-y-4" id="people_explore_section">
              <div className="flex items-center justify-between border-b border-slate-200/60 pb-2">
                <div className="flex items-center gap-2">
                  <Compass className="w-5 h-5 text-blue-500" />
                  <h2 className="text-xs sm:text-sm font-extrabold text-slate-700 uppercase tracking-wider">
                    {debouncedQuery ? `Matching Users (${filteredUsers.length})` : `Active Registered Users (${allUsers.length})`}
                  </h2>
                </div>
                {!debouncedQuery && (
                  <span className="text-[10px] font-semibold text-slate-400 bg-slate-100 px-2.5 py-0.5 rounded-full">
                    Discover people
                  </span>
                )}
              </div>

              {filteredUsers.length === 0 ? (
                <div className="text-center py-12 bg-white rounded-2xl border border-slate-150 p-6" id="no_users_matching">
                  <User className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                  <p className="text-xs font-semibold text-slate-500">No registered users matched "{searchQuery}"</p>
                  <p className="text-[10px] text-slate-400 mt-1">Try check your spelling or try search for another username.</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-5" id="explore_users_grid">
                  {filteredUsers.map((usr) => (
                    <motion.div
                      key={usr.uid}
                      whileHover={{ y: -5, scale: 1.02 }}
                      transition={{ type: 'spring', stiffness: 350, damping: 22 }}
                      onClick={() => onSelectUser(usr.uid)}
                      className="bg-white rounded-2xl border border-slate-200 shadow-xs hover:shadow-md transition duration-300 flex flex-col justify-between overflow-hidden cursor-pointer group"
                      id={`user_card_${usr.uid}`}
                    >
                      {/* Decorative Cover Header */}
                      <div className="h-14 w-full bg-linear-to-r from-blue-50 to-indigo-50 border-b border-slate-100 flex items-center justify-end px-3">
                        <span className="text-[9px] font-bold px-2 py-0.5 rounded-full bg-white text-slate-400 border border-slate-150 shadow-2xs">
                          @{usr.username}
                        </span>
                      </div>

                      {/* Body Content */}
                      <div className="p-4 flex flex-col items-center flex-1 -mt-8 relative z-10 text-center">
                        {/* Profile Photo */}
                        <div className="w-16 h-16 rounded-full border-4 border-white bg-slate-100 overflow-hidden shadow-sm mb-2 select-none">
                          <img
                            src={usr.photoURL || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&h=150'}
                            alt={usr.name}
                            className="w-full h-full object-cover"
                            referrerPolicy="no-referrer"
                          />
                        </div>

                        {/* Name Titles */}
                        <h3 className="font-bold text-slate-800 text-xs sm:text-sm group-hover:text-blue-600 transition truncate w-full px-1 leading-tight">
                          {usr.name}
                        </h3>

                        {/* Metadata Taglets */}
                        <div className="flex flex-wrap items-center justify-center gap-1 mt-3.5">
                          {usr.gender && usr.gender !== 'rather-not-say' && (
                            <span className="text-[9px] font-bold px-1.5 py-0.5 rounded-md capitalize bg-emerald-50 text-emerald-600 border border-emerald-100/60 font-mono">
                              {usr.gender}
                            </span>
                          )}
                          {usr.dob && (
                            <span className="text-[9px] font-bold px-1.5 py-0.5 rounded-md bg-amber-50 text-amber-700 border border-amber-100 font-mono">
                              {calculateAge(usr.dob)} yrs
                            </span>
                          )}
                          <span className="text-[9px] font-bold px-1.5 py-0.5 rounded-md bg-blue-50 text-blue-600 border border-blue-100 flex items-center gap-0.5">
                            <Sparkles className="w-2.5 h-2.5" />
                            {usr.friendsCount || 0} friends
                          </span>
                        </div>
                      </div>

                      {/* View Button Footer */}
                      <div className="border-t border-slate-100 p-2.5 bg-slate-50 text-center text-[10px] font-black text-blue-600 group-hover:bg-blue-600 group-hover:text-white transition uppercase tracking-wider">
                        View Profile
                      </div>
                    </motion.div>
                  ))}
                </div>
              )}
            </div>

            {/* Posts Matching Section (Only shown when searching) */}
            {debouncedQuery && (
              <div className="space-y-4" id="posts_explore_section">
                <div className="flex items-center gap-2 border-b border-slate-200/60 pb-2">
                  <FileText className="w-5 h-5 text-indigo-500" />
                  <h2 className="text-xs sm:text-sm font-extrabold text-slate-700 uppercase tracking-wider">
                    Post Matches ({postsResults.length})
                  </h2>
                </div>

                {postsResults.length === 0 ? (
                  <div className="text-center py-10 bg-white rounded-2xl border border-slate-150 p-6" id="no_posts_matching">
                    <FileText className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                    <p className="text-xs font-semibold text-slate-500">No posts matched "{searchQuery}"</p>
                    <p className="text-[10px] text-slate-400 mt-1">Try query topics or full text phrases.</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4" id="post_results_list">
                    {postsResults.map((post) => (
                      <div
                        key={post.id}
                        id={`search_post_${post.id}`}
                        onClick={() => onSelectPost(post.id)}
                        className="bg-white rounded-2xl border border-slate-150 p-4 hover:shadow-md hover:border-slate-300 transition cursor-pointer flex flex-col justify-between gap-3 duration-200 group"
                      >
                        <div className="flex items-center gap-2.5">
                          <div className="w-7 h-7 rounded-full overflow-hidden bg-slate-100 border shrink-0">
                            <img
                              src={post.authorPhotoURL || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&h=150'}
                              alt={post.authorName}
                              className="w-full h-full object-cover"
                              referrerPolicy="no-referrer"
                            />
                          </div>
                          <div>
                            <div className="text-[11px] font-black text-slate-800 leading-tight group-hover:text-blue-600 transition truncate max-w-[200px]">
                              {post.authorName}
                            </div>
                            <div className="text-[9.5px] text-slate-400 font-semibold leading-none">
                              @{post.authorUsername}
                            </div>
                          </div>
                        </div>

                        <div className="text-xs text-slate-600 line-clamp-3 leading-relaxed whitespace-pre-wrap break-words pl-2 border-l-2 border-blue-500/30">
                          {post.content}
                        </div>

                        {post.imageURL && (
                          <div className="truncate text-[9.5px] text-blue-600 font-bold bg-blue-50/60 px-2 py-0.5 rounded border border-blue-100/50 w-max mt-1 flex items-center gap-1 select-none">
                            <FileText className="w-3 h-3 text-blue-500 shrink-0" />
                            <span>Attachment Attached</span>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  );
}
