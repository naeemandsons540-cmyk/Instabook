import { useEffect, useState } from 'react';
import { collection, query, where, onSnapshot, doc, getDoc, orderBy } from 'firebase/firestore';
import { db, auth, OperationType, handleFirestoreError } from '../firebase';
import { Chat, UserProfile } from '../types';
import { MessageSquare, User, ArrowRight } from 'lucide-react';
import { motion } from 'motion/react';

interface ChatListProps {
  onSelectChat: (chatId: string) => void;
  onSelectUser: (userId: string) => void;
  blockedUserIds?: string[];
}

interface ChatListItem {
  chat: Chat;
  friendProfile: UserProfile | null;
}

export function ChatList({ onSelectChat, onSelectUser, blockedUserIds = [] }: ChatListProps) {
  const [conversations, setConversations] = useState<ChatListItem[]>([]);
  const [loading, setLoading] = useState(true);
  const currentUid = auth.currentUser?.uid;

  // 1. Listen to user's chat threads in real-time
  useEffect(() => {
    if (!currentUid) return;

    const chatCol = collection(db, 'chats');
    const q = query(chatCol, where('participants', 'array-contains', currentUid));

    const unsub = onSnapshot(q, async (snapshot) => {
      const list: ChatListItem[] = [];

      for (const dDoc of snapshot.docs) {
        const chatData = { id: dDoc.id, ...dDoc.data() } as Chat;
        
        // Find the friend ID (the participant that is not the current user)
        const friendId = chatData.participants.find(p => p !== currentUid);
        let friendProfile: UserProfile | null = null;

        if (friendId) {
          try {
            const fSnap = await getDoc(doc(db, 'users', friendId));
            if (fSnap.exists()) {
              friendProfile = fSnap.data() as UserProfile;
            }
          } catch (err) {
            console.error('Failed fetching chat friend profile:', err);
          }
        }

        list.push({
          chat: chatData,
          friendProfile: friendProfile
        });
      }

      // Sort chats by lastMessageTime descending
      list.sort((a, b) => {
        const ta = a.chat.lastMessageTime?.toDate ? a.chat.lastMessageTime.toDate().getTime() : 0;
        const tb = b.chat.lastMessageTime?.toDate ? b.chat.lastMessageTime.toDate().getTime() : 0;
        return tb - ta;
      });

      setConversations(list);
      setLoading(false);
    }, (err) => {
      console.error(err);
      handleFirestoreError(err, OperationType.GET, 'chats');
    });

    return () => unsub();
  }, [currentUid]);

  const formatMessageTime = (ts: any) => {
    if (!ts) return '';
    const date = ts.toDate ? ts.toDate() : new Date(ts);
    const diffMs = Date.now() - date.getTime();
    const diffHours = diffMs / (1000 * 60 * 60);

    if (diffHours < 24) {
      return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } else {
      return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 pb-20 font-sans select-none" id="chat_list_root">
      {/* Sticky Conversations Header */}
      <header className="sticky top-0 bg-white border-b border-slate-100 px-4 h-14 flex items-center justify-between z-30 shadow-sm lg:hidden" id="chat_list_header">
        <h1 className="font-extrabold text-slate-900 text-base sm:text-base.1">Direct Messages</h1>
        <MessageSquare className="w-5 h-5 text-blue-500 mr-1" />
      </header>

      {/* Primary chat scroll bodies */}
      <main className="max-w-md lg:max-w-2xl mx-auto p-4" id="conversations_body">
        {loading ? (
          <div className="flex flex-col items-center justify-center py-24 text-slate-400 gap-2" id="chat_list_spinner">
            <span className="w-6 h-6 block rounded-full border-3 border-blue-500 border-t-transparent animate-spin"></span>
            <span className="text-[11px] font-semibold text-slate-450">Loading conversations...</span>
          </div>
        ) : conversations.length === 0 ? (
          <div className="text-center py-20 bg-white rounded-2xl border border-slate-100 p-8" id="chats_blank_prompt">
            <MessageSquare className="w-12 h-12 text-slate-200 mx-auto mb-4 stroke-[1.2]" />
            <h3 className="font-bold text-sm text-slate-800">Your chat inbox is empty</h3>
            <p className="text-slate-400 text-xs mt-1 leading-snug">To start a real-time chat, use the **Search Tab** to select a user and click **Send Message** from their profile card.</p>
          </div>
        ) : (
          <div className="space-y-2" id="conversations_rows">
            {conversations
              .filter((item) => {
                const friendId = item.chat.participants.find(p => p !== currentUid);
                return friendId ? !blockedUserIds.includes(friendId) : true;
              })
              .map((item) => {
                const fProfile = item.friendProfile;
              return (
                <div
                  key={item.chat.id}
                  id={`chat_item_${item.chat.id}`}
                  onClick={() => onSelectChat(item.chat.id)}
                  className="p-3 bg-white rounded-2xl border border-slate-100 hover:bg-slate-50 transition relative flex items-center justify-between cursor-pointer"
                >
                  <div className="flex items-center gap-3.5 min-w-0 pr-2">
                    {/* Friend Avatar */}
                    <div
                      onClick={(e) => {
                        e.stopPropagation();
                        if (fProfile?.uid) onSelectUser(fProfile.uid);
                      }}
                      className="w-11 h-11 rounded-full overflow-hidden bg-slate-50 border border-slate-100 shrink-0 cursor-pointer"
                    >
                      {fProfile?.photoURL ? (
                        <img src={fProfile.photoURL} alt={fProfile.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                      ) : (
                        <User className="w-6 h-6 text-slate-400 m-auto mt-2" />
                      )}
                    </div>

                    {/* Meta details preview */}
                    <div className="min-w-0">
                      <div className="font-extrabold text-slate-950 text-xs leading-none mb-1">{fProfile?.name || 'Social Friend'}</div>
                      <p className="text-[11px] text-slate-500 truncate leading-relaxed max-w-[210px]">
                        {item.chat.lastMessageSenderId === currentUid ? 'You: ' : ''}
                        {item.chat.lastMessage}
                      </p>
                    </div>
                  </div>

                  {/* Date and Navigation specs */}
                  <div className="flex flex-col items-end gap-1 shrink-0">
                    <span className="text-[9px] text-slate-400 font-bold">{formatMessageTime(item.chat.lastMessageTime)}</span>
                    <ArrowRight className="w-4 h-4 text-slate-300" />
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </main>
    </div>
  );
}
