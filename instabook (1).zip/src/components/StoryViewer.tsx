import { useEffect, useState } from 'react';
import { Story } from '../types';
import { X, ChevronLeft, ChevronRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface StoryViewerProps {
  groupedStories: { authorId: string; stories: Story[] }[];
  initialGroupIndex: number;
  onClose: () => void;
}

export function StoryViewer({
  groupedStories,
  initialGroupIndex,
  onClose,
}: StoryViewerProps) {
  const [groupIndex, setGroupIndex] = useState(initialGroupIndex);
  const [storyIndex, setStoryIndex] = useState(0);
  const [progress, setProgress] = useState(0);

  const duration = 5000; // 5 seconds per story
  const currentGroup = groupedStories[groupIndex];
  const currentStory = currentGroup?.stories[storyIndex];

  // Auto-advance timer
  useEffect(() => {
    setProgress(0);
    const intervalTime = 50;
    const steps = duration / intervalTime;
    let currentStep = 0;

    const timer = setInterval(() => {
      currentStep++;
      const currentProgress = (currentStep / steps) * 100;
      setProgress(currentProgress);

      if (currentStep >= steps) {
        clearInterval(timer);
        handleNext();
      }
    }, intervalTime);

    return () => clearInterval(timer);
  }, [groupIndex, storyIndex]);

  if (!currentStory) {
    onClose();
    return null;
  }

  const handleNext = () => {
    if (storyIndex < currentGroup.stories.length - 1) {
      setStoryIndex((prev) => prev + 1);
    } else if (groupIndex < groupedStories.length - 1) {
      setGroupIndex((prev) => prev + 1);
      setStoryIndex(0);
    } else {
      onClose();
    }
  };

  const handlePrev = () => {
    if (storyIndex > 0) {
      setStoryIndex((prev) => prev - 1);
    } else if (groupIndex > 0) {
      setGroupIndex((prev) => prev - 1);
      setStoryIndex(groupedStories[groupIndex - 1].stories.length - 1);
    } else {
      setStoryIndex(0); // Restart current first video/story
    }
  };

  // Convert Firestore Timestamp or JS Date to user-friendly human string
  const formatTime = (ts: any) => {
    if (!ts) return '';
    const date = ts.toDate ? ts.toDate() : new Date(ts);
    return date.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
  };

  return (
    <div
      className="fixed inset-0 bg-black z-50 flex items-center justify-center font-sans touch-none"
      id="story_viewer_viewport"
    >
      <div className="absolute inset-0 bg-cover bg-center filter blur-xl opacity-40" style={{ backgroundImage: `url(${currentStory.imageURL})` }} />

      <div className="w-full max-w-md h-full relative flex flex-col justify-between bg-zinc-950 text-white select-none">
        {/* Top Progress Bars & Headers */}
        <div className="absolute top-0 inset-x-0 p-4 bg-gradient-to-b from-black/80 to-transparent z-10">
          {/* Progression Line Indicators */}
          <div className="flex gap-1 mb-3.5">
            {currentGroup.stories.map((s, idx) => {
              let fillWidth = 0;
              if (idx < storyIndex) fillWidth = 100;
              else if (idx === storyIndex) fillWidth = progress;

              return (
                <div key={s.id} className="h-1 flex-1 bg-zinc-700/60 rounded-full overflow-hidden">
                  <div className="h-full bg-blue-500 transition-all duration-[50ms]" style={{ width: `${fillWidth}%` }} />
                </div>
              );
            })}
          </div>

          {/* Publisher Specs Header */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-full overflow-hidden bg-slate-200 border border-white/20">
                <img src={currentStory.authorPhotoURL || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&h=150'} alt="Author" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
              </div>
              <div>
                <div className="font-bold text-xs">{currentStory.authorUsername}</div>
                <div className="text-[10px] text-zinc-300 font-medium">{formatTime(currentStory.createdAt)}</div>
              </div>
            </div>

            <button id="close_story_btn" onClick={onClose} className="p-2 hover:bg-white/10 rounded-full transition cursor-pointer">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Swipe Tap Boundaries */}
        <div className="flex-1 flex items-center justify-center relative touch-pan-y" id="story_stage">
          <AnimatePresence mode="wait">
            <motion.img
              key={currentStory.id}
              initial={{ opacity: 0.8, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0.8, scale: 0.98 }}
              transition={{ duration: 0.2 }}
              src={currentStory.imageURL}
              alt="Story"
              className="max-h-full max-w-full object-contain pointer-events-none"
              referrerPolicy="no-referrer"
            />
          </AnimatePresence>

          {/* Left Navigate boundary clicker */}
          <div className="absolute inset-y-0 left-0 w-1/4 cursor-pointer" onClick={handlePrev} />
          {/* Right Navigate boundary clicker */}
          <div className="absolute inset-y-0 right-0 w-1/4 cursor-pointer" onClick={handleNext} />

          {/* Desktop Left/Right Manual buttons */}
          <button
            onClick={handlePrev}
            className="absolute left-3 top-1/2 -translate-y-1/2 p-2 bg-black/45 rounded-full hover:bg-black/70 text-white/80 select-none cursor-pointer hidden md:block"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <button
            onClick={handleNext}
            className="absolute right-3 top-1/2 -translate-y-1/2 p-2 bg-black/45 rounded-full hover:bg-black/70 text-white/80 select-none cursor-pointer hidden md:block"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
}
