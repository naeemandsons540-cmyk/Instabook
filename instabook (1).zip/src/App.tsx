import { useEffect, useState, useMemo } from 'react';
import { onAuthStateChanged, User } from 'firebase/auth';
import { doc, getDoc, setDoc, collection, query, orderBy, onSnapshot, where, updateDoc, increment, deleteDoc } from 'firebase/firestore';
import { auth, db, handleFirestoreError, OperationType } from './firebase';
import { AppState, UserProfile, Story, ViewType } from './types';
import { Home, Search, Bell, MessageSquare, User as UserIcon, Plus, Menu, X, ShieldAlert } from 'lucide-react';

// Page Screen Imports
import { AuthScreen } from './components/AuthScreen';
import { OnboardingScreen } from './components/OnboardingScreen';
import { BottomNav } from './components/BottomNav';
import { FeedView } from './components/FeedView';
import { SearchView } from './components/SearchView';
import { NotificationsView } from './components/NotificationsView';
import { ChatList } from './components/ChatList';
import { ChatView } from './components/ChatView';
import { ProfileView } from './components/ProfileView';
import { PostDetail } from './components/PostDetail';
import { CreatePostModal } from './components/CreatePostModal';
import { StoryViewer } from './components/StoryViewer';

interface SidebarChatItem {
  id: string;
  lastMessage: string;
  friendName: string;
  friendPhoto: string;
  friendUsername: string;
}

export default function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [checkingUser, setCheckingUser] = useState(true);
  const [needsOnboarding, setNeedsOnboarding] = useState(false);
  const [isMobileDrawerOpen, setIsMobileDrawerOpen] = useState(false);

  // Block states
  const [myBlockedUsers, setMyBlockedUsers] = useState<any[]>([]);
  const [outgoingBlockedIds, setOutgoingBlockedIds] = useState<string[]>([]);
  const [incomingBlockedIds, setIncomingBlockedIds] = useState<string[]>([]);

  const blockedUserIds = useMemo(() => {
    return Array.from(new Set([...outgoingBlockedIds, ...incomingBlockedIds]));
  }, [outgoingBlockedIds, incomingBlockedIds]);

  // Core navigation state
  const [state, setState] = useState<AppState>({
    currentView: 'feed',
    selectedPostId: null,
    selectedChatId: null,
    selectedUserId: null,
    activeStoryIndex: null,
    storiesList: [],
  });

  // Action count badges
  const [unreadNotifications, setUnreadNotifications] = useState(0);
  const [unreadChats, setUnreadChats] = useState(0);

  // Search query shared state
  const [searchQuery, setSearchQuery] = useState('');

  // Sidebar live datasets
  const [rightSidebarChats, setRightSidebarChats] = useState<SidebarChatItem[]>([]);
  const [rightSidebarFriendRequests, setRightSidebarFriendRequests] = useState<any[]>([]);

  // Real-time Sidebar Direct Messages
  useEffect(() => {
    if (!currentUser || needsOnboarding) return;

    const chatCol = collection(db, 'chats');
    const q = query(chatCol, where('participants', 'array-contains', currentUser.uid));

    const unsub = onSnapshot(q, async (snapshot) => {
      const list: SidebarChatItem[] = [];

      for (const dDoc of snapshot.docs) {
        const chatData = dDoc.data();
        const friendId = chatData.participants?.find((p: string) => p !== currentUser.uid);
        let friendName = 'Social User';
        let friendPhoto = '';
        let friendUsername = '';

        if (friendId) {
          try {
            const fSnap = await getDoc(doc(db, 'users', friendId));
            if (fSnap.exists()) {
              const fData = fSnap.data();
              friendName = fData.name || 'Social User';
              friendPhoto = fData.photoURL || '';
              friendUsername = fData.username || '';
            }
          } catch (err) {
            console.error('Error fetching sidebar friend:', err);
          }
        }

        list.push({
          id: dDoc.id,
          lastMessage: chatData.lastMessage || 'Started thread.',
          friendName,
          friendPhoto,
          friendUsername,
        });
      }
      setRightSidebarChats(list);
    });

    return () => unsub();
  }, [currentUser, needsOnboarding]);

  // Real-time Sidebar Friend Requests
  useEffect(() => {
    if (!currentUser || needsOnboarding) return;

    const colRef = collection(db, 'friendRequests');
    const q = query(colRef, where('receiverId', '==', currentUser.uid), where('status', '==', 'pending'));

    const unsub = onSnapshot(q, (snapshot) => {
      const list: any[] = [];
      snapshot.forEach((dDoc) => {
        list.push({ id: dDoc.id, ...dDoc.data() });
      });
      setRightSidebarFriendRequests(list);
    });

    return () => unsub();
  }, [currentUser, needsOnboarding]);

  const handleAcceptRequestSidebar = async (req: any) => {
    if (!currentUser || !userProfile) return;
    try {
      const reqRef = doc(db, 'friendRequests', req.id);
      await updateDoc(reqRef, { status: 'accepted' });

      const refOwn = doc(db, 'users', currentUser.uid, 'friends', req.senderId);
      const refOther = doc(db, 'users', req.senderId, 'friends', currentUser.uid);

      await setDoc(refOwn, { uid: req.senderId, name: req.senderName, photoURL: req.senderPhoto, username: req.senderUsername });
      await setDoc(refOther, { uid: currentUser.uid, name: userProfile.name, photoURL: userProfile.photoURL, username: userProfile.username });

      // Update counters
      await updateDoc(doc(db, 'users', currentUser.uid), { friendsCount: (userProfile.friendsCount || 0) + 1 });
      
      const senderRef = doc(db, 'users', req.senderId);
      const senderSnap = await getDoc(senderRef);
      if (senderSnap.exists()) {
        const senderData = senderSnap.data();
        await updateDoc(senderRef, { friendsCount: (senderData.friendsCount || 0) + 1 });
      }

      // Create notification
      const notId = `${currentUser.uid}_friend_accept_${Date.now()}`;
      await setDoc(doc(db, 'users', req.senderId, 'notifications', notId), {
        id: notId,
        actorId: currentUser.uid,
        actorName: userProfile.name,
        actorPhotoURL: userProfile.photoURL,
        type: 'friend_accept',
        text: 'accepted your friend connection request',
        isRead: false,
        createdAt: new Date()
      });

      handleProfileRefresh();
    } catch (err) {
      console.error('Failed to accept sidebar request:', err);
    }
  };

  const handleDeclineRequestSidebar = async (req: any) => {
    try {
      const reqRef = doc(db, 'friendRequests', req.id);
      await updateDoc(reqRef, { status: 'declined' });
    } catch (err) {
      console.error('Failed to decline sidebar request:', err);
    }
  };

  // 1. Authenticated listener hook
  useEffect(() => {
    let unsubProfile: (() => void) | null = null;
    const unsubAuth = onAuthStateChanged(auth, async (parsedUser) => {
      setCheckingUser(true);
      if (parsedUser) {
        setCurrentUser(parsedUser);
        
        // Setup real-time listener for current user's profile doc
        unsubProfile = onSnapshot(doc(db, 'users', parsedUser.uid), (snap) => {
          if (snap.exists()) {
            setUserProfile(snap.data() as UserProfile);
            setNeedsOnboarding(false);
          } else {
            setUserProfile(null);
            setNeedsOnboarding(true);
          }
        }, (err) => {
          console.error('Failed listening to user profile in database:', err);
        });
      } else {
        setCurrentUser(null);
        setUserProfile(null);
        setNeedsOnboarding(false);
        if (unsubProfile) {
          unsubProfile();
          unsubProfile = null;
        }
      }
      setCheckingUser(false);
    });

    return () => {
      unsubAuth();
      if (unsubProfile) unsubProfile();
    };
  }, []);

  // 2. Refresh profile details after changes
  const handleProfileRefresh = async (createdProfile?: UserProfile) => {
    if (!currentUser) return;
    if (createdProfile) {
      setUserProfile(createdProfile);
      setNeedsOnboarding(false);
      return;
    }
    try {
      const snap = await getDoc(doc(db, 'users', currentUser.uid));
      if (snap.exists()) {
        setUserProfile(snap.data() as UserProfile);
        setNeedsOnboarding(false);
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Real-time listener for blocks involving the user
  useEffect(() => {
    if (!currentUser || needsOnboarding) {
      setMyBlockedUsers([]);
      setOutgoingBlockedIds([]);
      setIncomingBlockedIds([]);
      return;
    }

    const blocksCol = collection(db, 'blocks');
    const qOutgoing = query(blocksCol, where('blockerId', '==', currentUser.uid));
    const unsubOutgoing = onSnapshot(qOutgoing, (snapshot) => {
      const list: any[] = [];
      const ids: string[] = [];
      snapshot.forEach((doc) => {
        const d = { id: doc.id, ...doc.data() } as any;
        list.push(d);
        ids.push(d.blockedId);
      });
      setMyBlockedUsers(list);
      setOutgoingBlockedIds(ids);
    }, (err) => {
      console.error('Outgoing block fetch failure:', err);
    });

    const qIncoming = query(blocksCol, where('blockedId', '==', currentUser.uid));
    const unsubIncoming = onSnapshot(qIncoming, (snapshot) => {
      const ids: string[] = [];
      snapshot.forEach((doc) => {
        ids.push(doc.data().blockerId);
      });
      setIncomingBlockedIds(ids);
    }, (err) => {
      console.error('Incoming block fetch failure:', err);
    });

    return () => {
      unsubOutgoing();
      unsubIncoming();
    };
  }, [currentUser, needsOnboarding]);

  // 3. Listen to Active Stories in real-time
  useEffect(() => {
    if (!currentUser || needsOnboarding) return;

    const sCol = collection(db, 'stories');
    const q = query(sCol, orderBy('createdAt', 'desc'));

    const unsubStories = onSnapshot(q, (snapshot) => {
      const rawStories: Story[] = [];
      snapshot.forEach((doc) => {
        const data = doc.data() as Story;
        
        // Strict boundary checking: expire stories older than 24h
        const sTime = data.createdAt?.toDate ? data.createdAt.toDate() : new Date(data.createdAt);
        const hoursAge = (Date.now() - sTime.getTime()) / (1000 * 60 * 60);
        if (hoursAge < 24) {
          rawStories.push({ id: doc.id, ...data } as Story);
        }
      });

      // Group stories by authorId
      const groups: { [authorId: string]: Story[] } = {};
      rawStories.forEach((s) => {
        if (!groups[s.authorId]) groups[s.authorId] = [];
        groups[s.authorId].push(s);
      });

      const groupedList = Object.keys(groups).map((authorId) => ({
        authorId,
        stories: groups[authorId],
      }));

      setState((prev) => ({ ...prev, storiesList: groupedList }));
    }, (err) => {
      console.error(err);
      handleFirestoreError(err, OperationType.GET, 'stories');
    });

    return () => unsubStories();
  }, [currentUser, needsOnboarding]);

  // 4. Listen to unread notifications count
  useEffect(() => {
    if (!currentUser || needsOnboarding) return;

    const notCol = collection(db, 'users', currentUser.uid, 'notifications');
    const qUnread = query(notCol);

    const unsubNotif = onSnapshot(qUnread, (snapshot) => {
      let unreads = 0;
      snapshot.forEach((doc) => {
        if (doc.data().isRead === false) unreads++;
      });
      setUnreadNotifications(unreads);
    });

    return () => unsubNotif();
  }, [currentUser, needsOnboarding]);

  // 5. Navigate viewport checks
  const changeView = (newView: ViewType) => {
    setState((prev) => ({
      ...prev,
      currentView: newView,
      // Clear thread spec details when tapping bottom nav
      selectedPostId: null,
      selectedChatId: null,
      selectedUserId: null,
    }));
  };

  const handleSelectPost = (postId: string) => {
    setState((prev) => ({ ...prev, selectedPostId: postId }));
  };

  const handleSelectUser = (userId: string) => {
    setState((prev) => ({
      ...prev,
      currentView: 'profile',
      selectedUserId: userId,
      selectedPostId: null, // Clear thread if inspecting user profile
    }));
  };

  // direct message starting handshake helper
  const handleStartChat = async (friendId: string) => {
    if (!currentUser) return;
    
    // Sort UIDs deterministically to get unique bidirectional chatId
    const sortedIds = [currentUser.uid, friendId].sort();
    const chatId = `${sortedIds[0]}_${sortedIds[1]}`;

    try {
      // Setup base Chat thread document if not exist
      const chatRef = doc(db, 'chats', chatId);
      const chatSnap = await getDoc(chatRef);

      if (!chatSnap.exists()) {
        await setDoc(chatRef, {
          id: chatId,
          participants: sortedIds,
          lastMessage: 'Started thread.',
          lastMessageSenderId: currentUser.uid,
          lastMessageTime: new Date()
        });
      }

      setState((prev) => ({
        ...prev,
        currentView: 'messages',
        selectedChatId: chatId,
        selectedUserId: null,
      }));
    } catch (err) {
      console.error('Failed to initialize DM chat:', err);
    }
  };

  if (checkingUser) {
    return (
      <div className="min-h-screen bg-white flex flex-col items-center justify-center p-6 text-center select-none" id="app_init_loader">
        <div className="flex flex-col items-center gap-4.5">
          <div className="w-12 h-12 bg-blue-600 rounded-3xl animate-ping opacity-60 flex items-center justify-center text-white text-lg font-black shrink-0">iB</div>
          <span className="text-slate-400 text-xs font-bold font-mono uppercase tracking-wider">Syncing Instabook...</span>
        </div>
      </div>
    );
  }

  // Not Logged In screen Page
  if (!currentUser) {
    return <AuthScreen onCheckingUser={setCheckingUser} />;
  }

  // Completing User Onboarding screen Page
  if (needsOnboarding) {
    return <OnboardingScreen onComplete={handleProfileRefresh} />;
  }

  return (
    <div className="min-h-screen md:h-screen w-full bg-slate-50 text-slate-900 flex flex-col md:flex-row relative md:overflow-hidden select-none" id="app_shell">
      {/* LEFT SIDEBAR: NAVIGATION (Hidden on mobile, visible on tablet & desktop) */}
      <aside className="bg-white border-r border-slate-200 hidden md:flex md:w-20 lg:w-64 flex-col select-none shrink-0 transition-all duration-300" id="desktop_left_sidebar">
        <div className="p-4 lg:p-6 text-center lg:text-left flex items-center justify-center lg:justify-start shrink-0">
          <h1 className="text-xl lg:text-2xl font-black text-blue-600 tracking-tighter hover:opacity-80 transition cursor-pointer hidden lg:block" onClick={() => changeView('feed')}>
            INSTABOOK
          </h1>
          <h1 className="text-xl font-black text-blue-600 tracking-tighter hover:opacity-80 transition cursor-pointer block lg:hidden" onClick={() => changeView('feed')}>
            IB
          </h1>
        </div>
        <nav className="flex-grow px-2 lg:px-4 space-y-1.5 pt-2 lg:pt-4">
          <button
            onClick={() => changeView('feed')}
            className={`w-full flex items-center lg:space-x-3 px-3 lg:px-4 py-3 rounded-xl font-semibold text-sm transition cursor-pointer justify-center lg:justify-start ${
              state.currentView === 'feed'
                ? 'bg-blue-50 text-blue-600 font-bold'
                : 'text-slate-500 hover:bg-slate-50 hover:text-slate-800'
            }`}
          >
            <Home className={`w-5 h-5 shrink-0 ${state.currentView === 'feed' ? 'text-blue-600' : 'text-slate-400'}`} />
            <span className="flex-1 lg:block hidden text-left">Feed</span>
          </button>

          <button
            onClick={() => changeView('search')}
            className={`w-full flex items-center lg:space-x-3 px-3 lg:px-4 py-3 rounded-xl font-semibold text-sm transition cursor-pointer justify-center lg:justify-start ${
              state.currentView === 'search'
                ? 'bg-blue-50 text-blue-600 font-bold'
                : 'text-slate-500 hover:bg-slate-50 hover:text-slate-800'
            }`}
          >
            <Search className={`w-5 h-5 shrink-0 ${state.currentView === 'search' ? 'text-blue-600' : 'text-slate-400'}`} />
            <span className="flex-1 lg:block hidden text-left">Explore</span>
          </button>

          <button
            onClick={() => changeView('notifications')}
            className={`w-full flex items-center lg:space-x-3 px-3 lg:px-4 py-3 rounded-xl font-semibold text-sm transition cursor-pointer justify-center lg:justify-start relative ${
              state.currentView === 'notifications'
                ? 'bg-blue-50 text-blue-600 font-bold'
                : 'text-slate-500 hover:bg-slate-50 hover:text-slate-800'
            }`}
          >
            <Bell className={`w-5 h-5 shrink-0 ${state.currentView === 'notifications' ? 'text-blue-600' : 'text-slate-400'}`} />
            <span className="flex-1 lg:block hidden text-left">Notifications</span>
            {unreadNotifications > 0 && (
              <span className="bg-red-500 text-white text-[10px] px-1.5 py-0.5 rounded-full font-bold lg:ml-auto lg:relative absolute top-1.5 right-1.5 lg:top-0 lg:right-0 animate-pulse shrink-0">
                {unreadNotifications}
              </span>
            )}
          </button>

          <button
            onClick={() => changeView('messages')}
            className={`w-full flex items-center lg:space-x-3 px-3 lg:px-4 py-3 rounded-xl font-semibold text-sm transition cursor-pointer justify-center lg:justify-start relative ${
              state.currentView === 'messages'
                ? 'bg-blue-50 text-blue-600 font-bold'
                : 'text-slate-500 hover:bg-slate-50 hover:text-slate-800'
            }`}
          >
            <MessageSquare className={`w-5 h-5 shrink-0 ${state.currentView === 'messages' ? 'text-blue-600' : 'text-slate-400'}`} />
            <span className="flex-1 lg:block hidden text-left">Messages</span>
            {unreadChats > 0 && (
              <span className="bg-red-500 text-white text-[10px] px-1.5 py-0.5 rounded-full font-bold lg:ml-auto lg:relative absolute top-1.5 right-1.5 lg:top-0 lg:right-0 shrink-0">
                {unreadChats}
              </span>
            )}
          </button>

          <button
            onClick={() => changeView('profile')}
            className={`w-full flex items-center lg:space-x-3 px-3 lg:px-4 py-3 rounded-xl font-semibold text-sm transition cursor-pointer justify-center lg:justify-start ${
              state.currentView === 'profile'
                ? 'bg-blue-50 text-blue-600 font-bold'
                : 'text-slate-500 hover:bg-slate-50 hover:text-slate-800'
            }`}
          >
            <UserIcon className={`w-5 h-5 shrink-0 ${state.currentView === 'profile' ? 'text-blue-600' : 'text-slate-400'}`} />
            <span className="flex-1 lg:block hidden text-left">Profile</span>
          </button>
          
          <button
            onClick={() => setState((prev) => ({ ...prev, currentView: 'create_post' }))}
            className="w-full mt-6 bg-blue-600 text-white font-bold py-3 rounded-xl text-xs flex items-center justify-center gap-1.5 hover:bg-blue-700 active:scale-98 transition shadow-lg shadow-blue-200 cursor-pointer px-2"
          >
            <Plus className="w-4.5 h-4.5 stroke-[2.5] shrink-0" />
            <span className="lg:block hidden">Create Post</span>
          </button>
        </nav>
        {userProfile && (
          <div className="p-3 lg:p-4 border-t border-slate-100 shrink-0">
            <div 
              className="flex items-center lg:space-x-3 p-1 rounded-xl transition cursor-pointer justify-center lg:justify-start hover:bg-slate-50"
              onClick={() => handleSelectUser(userProfile.uid)}
            >
              <div className="w-10 h-10 rounded-full border border-slate-200 overflow-hidden bg-slate-100 shrink-0 select-none">
                <img src={userProfile.photoURL || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&h=150'} alt="Your Avatar" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
              </div>
              <div className="overflow-hidden leading-tight flex-1 text-left lg:block hidden">
                <p className="text-xs font-black text-slate-800 truncate">{userProfile.name}</p>
                <p className="text-[10px] text-slate-450 truncate">@{userProfile.username}</p>
              </div>
            </div>
          </div>
        )}
      </aside>

      {/* CENTER AREA: MAIN HUB */}
      <main className="flex-grow flex flex-col min-w-0 bg-slate-50 h-full md:overflow-hidden relative" id="desktop_main_content">
        
        {/* MOBILE TOP HEADER (Sticky top bar for compact viewports) */}
        <header className="h-14 bg-white border-b border-slate-100 px-4 flex md:hidden items-center justify-between shrink-0 select-none sticky top-0 z-30" id="mobile_header">
          <div className="flex items-center space-x-3">
            {userProfile ? (
              <button 
                onClick={() => handleSelectUser(userProfile.uid)}
                className="w-8 h-8 rounded-full border border-slate-200 overflow-hidden bg-slate-100 shrink-0 focus:outline-none"
              >
                <img 
                  src={userProfile.photoURL || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&h=150'} 
                  alt="" 
                  className="w-full h-full object-cover" 
                  referrerPolicy="no-referrer" 
                />
              </button>
            ) : (
              <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center">
                <UserIcon className="w-4 h-4 text-slate-400" />
              </div>
            )}
            <h1 className="text-lg font-black text-blue-600 tracking-tight cursor-pointer" onClick={() => changeView('feed')}>
              Instabook
            </h1>
          </div>
          <div className="flex items-center space-x-2">
            <button 
              onClick={() => changeView('search')}
              className="p-2 bg-slate-50 hover:bg-slate-100 rounded-xl text-slate-500 hover:text-slate-700 transition lg:hidden"
              title="Search"
            >
              <Search className="w-4 h-4" />
            </button>
            <button
              onClick={() => setIsMobileDrawerOpen(true)}
              className="p-2 bg-blue-50/80 hover:bg-blue-100 text-blue-600 rounded-xl transition relative cursor-pointer"
              title="Connections"
            >
              <Menu className="w-4.5 h-4.5 stroke-[2.2]" />
              {(rightSidebarFriendRequests.length > 0 || unreadNotifications > 0) && (
                <span className="absolute top-1 right-1 w-2.2 h-2.2 bg-rose-500 rounded-full border border-white animate-pulse"></span>
              )}
            </button>
          </div>
        </header>

        {/* DESKTOP HEADER */}
        <header className="h-16 bg-white border-b border-slate-200 px-6 sm:px-8 hidden md:flex items-center justify-between shrink-0 select-none" id="desktop_header">
          <div className="relative w-72 sm:w-96">
            <input
              type="text"
              placeholder="Search users, posts..."
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                if (state.currentView !== 'search') {
                  changeView('search');
                }
              }}
              onClick={() => {
                if (state.currentView !== 'search') {
                  changeView('search');
                }
              }}
              className="w-full bg-slate-100 border-none rounded-full py-2 pl-10 pr-4 text-xs transition focus:ring-2 focus:ring-blue-500/20 outline-none hover:bg-slate-200/50 text-slate-800"
            />
            <Search className="absolute left-3.5 top-2.5 w-4 h-4 text-slate-400" />
          </div>
          <button 
            onClick={() => setState((prev) => ({ ...prev, currentView: 'create_post' }))}
            className="bg-blue-600 text-white px-5 py-2 rounded-full text-xs font-bold shadow-lg shadow-blue-100 hover:bg-blue-700 cursor-pointer active:scale-95 transition"
          >
            + Create Post
          </button>
        </header>

        {/* CONTAINER VIEWPORT */}
        <div className="flex-grow overflow-y-auto w-full pb-16 lg:pb-0" id="desktop_center_viewport">
          <div className="w-full lg:max-w-4xl mx-auto lg:p-6 p-0" id="routed_view_wrapper_inner">
            {state.selectedPostId ? (
              <PostDetail
                postId={state.selectedPostId}
                currentUserProfile={userProfile}
                onBack={() => setState((prev) => ({ ...prev, selectedPostId: null }))}
                onSelectUser={handleSelectUser}
              />
            ) : state.currentView === 'feed' ? (
              <FeedView
                currentUserProfile={userProfile}
                onSelectPost={handleSelectPost}
                onSelectUser={handleSelectUser}
                onSelectStoryGroup={(idx) => setState((prev) => ({ ...prev, activeStoryIndex: idx }))}
                onCreatePostClick={() => setState((prev) => ({ ...prev, currentView: 'create_post' }))}
                groupedStories={state.storiesList}
                blockedUserIds={blockedUserIds}
              />
            ) : state.currentView === 'search' ? (
              <SearchView
                onSelectPost={handleSelectPost}
                onSelectUser={handleSelectUser}
                searchQuery={searchQuery}
                setSearchQuery={setSearchQuery}
                blockedUserIds={blockedUserIds}
              />
            ) : state.currentView === 'messages' ? (
              state.selectedChatId && state.storiesList ? (
                (() => {
                  const parts = state.selectedChatId.split('_');
                  const friendId = parts.find(p => p !== currentUser?.uid);
                  return (
                    <ChatView
                      chatId={state.selectedChatId}
                      friendProfile={null}
                      currentUserProfile={userProfile}
                      onBack={() => setState((prev) => ({ ...prev, selectedChatId: null }))}
                    />
                  );
                })()
              ) : (
                <ChatList
                  onSelectChat={(cId) => setState((prev) => ({ ...prev, selectedChatId: cId }))}
                  onSelectUser={handleSelectUser}
                  blockedUserIds={blockedUserIds}
                />
              )
            ) : state.currentView === 'notifications' ? (
              <NotificationsView
                onSelectPost={handleSelectPost}
                onSelectUser={handleSelectUser}
                blockedUserIds={blockedUserIds}
              />
            ) : state.currentView === 'profile' ? (
              <ProfileView
                userId={state.selectedUserId}
                currentUserProfile={userProfile}
                onSelectPost={handleSelectPost}
                onSelectUser={handleSelectUser}
                onStartChat={handleStartChat}
                onProfileUpdated={handleProfileRefresh}
                blockedUserIds={blockedUserIds}
                myBlockedUsers={myBlockedUsers}
              />
            ) : state.currentView === 'create_post' ? (
              <CreatePostModal
                currentUserProfile={userProfile}
                onPostCreated={() => setState((prev) => ({ ...prev, currentView: 'feed' }))}
                onClose={() => setState((prev) => ({ ...prev, currentView: 'feed' }))}
              />
            ) : null}

            {/* Overlays */}
            {state.activeStoryIndex !== null && state.storiesList[state.activeStoryIndex] && (
              <StoryViewer
                groupedStories={state.storiesList}
                initialGroupIndex={state.activeStoryIndex}
                onClose={() => setState((prev) => ({ ...prev, activeStoryIndex: null }))}
              />
            )}
          </div>
        </div>
      </main>

      {/* RIGHT SIDEBAR: OTHER USERS & SUGGESTIONS (Hidden on mobile/tablet, visible on extra wide screens) */}
      <aside className="w-80 bg-white border-l border-slate-200 hidden xl:flex flex-col select-none shrink-0" id="desktop_right_sidebar">
        <div className="p-5 border-b border-slate-100 flex items-center justify-between">
          <h3 className="text-xs font-black uppercase tracking-widest text-slate-400">Direct Messages</h3>
          <button className="text-[10px] text-blue-600 font-bold hover:underline cursor-pointer" onClick={() => changeView('messages')}>View Chats</button>
        </div>
        <div className="flex-1 overflow-y-auto px-4 py-3 space-y-3">
          {rightSidebarChats.filter(chat => {
            const friendId = chat.id.split('_').find(p => p !== currentUser?.uid);
            return friendId ? !blockedUserIds.includes(friendId) : true;
          }).length === 0 ? (
            <div className="text-center py-6 text-slate-450 text-[11px] leading-tight flex flex-col items-center justify-center gap-1.5 h-32">
              <MessageSquare className="w-5 h-5 text-slate-200" />
              <span>No messages yet</span>
            </div>
          ) : (
            rightSidebarChats
              .filter(chat => {
                const friendId = chat.id.split('_').find(p => p !== currentUser?.uid);
                return friendId ? !blockedUserIds.includes(friendId) : true;
              })
              .slice(0, 5)
              .map((chat) => (
              <div
                key={chat.id}
                onClick={() => {
                  setState((prev) => ({
                    ...prev,
                    currentView: 'messages',
                    selectedChatId: chat.id,
                    selectedUserId: null,
                  }));
                }}
                className="flex items-center space-x-3 p-2 rounded-xl hover:bg-slate-50 transition cursor-pointer"
              >
                <div className="relative shrink-0">
                  <div className="w-9 h-9 rounded-full bg-slate-100 overflow-hidden border border-slate-200 flex items-center justify-center">
                    {chat.friendPhoto ? (
                      <img src={chat.friendPhoto} alt="" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                    ) : (
                      <UserIcon className="w-4 h-4 text-slate-400" />
                    )}
                  </div>
                  <div className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-green-500 rounded-full border-2 border-white"></div>
                </div>
                <div className="flex-1 min-w-0 font-medium leading-tight">
                  <div className="flex justify-between items-baseline mb-0.5">
                    <p className="text-xs font-bold text-slate-800 truncate">{chat.friendName || 'Social User'}</p>
                  </div>
                  <p className="text-[10px] text-slate-400 truncate">{chat.lastMessage}</p>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Friend Requests */}
        <div className="p-4 bg-slate-50 m-4 rounded-2xl border border-slate-150">
          <h3 className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-3.5">Friend Requests</h3>
          {rightSidebarFriendRequests.length === 0 ? (
            <p className="text-[10px] text-slate-450 font-semibold text-center py-4">No pending requests</p>
          ) : (
            <div className="space-y-3">
              {rightSidebarFriendRequests.map((req) => (
                <div key={req.id} className="flex items-center justify-between bg-white p-2 rounded-xl border border-slate-100 shadow-sm">
                  <div className="flex items-center space-x-2 min-w-0">
                    <div className="w-7 h-7 rounded-full overflow-hidden bg-slate-100 border border-slate-200 shrink-0">
                      <img src={req.senderPhoto || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&h=150'} alt="" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                    </div>
                    <div className="truncate min-w-0">
                      <p className="text-[10px] font-bold text-slate-800 truncate leading-tight">{req.senderName}</p>
                      <p className="text-[8.5px] text-slate-400 truncate leading-none">@{req.senderUsername}</p>
                    </div>
                  </div>
                  <div className="flex space-x-1.2 shrink-0">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleAcceptRequestSidebar(req);
                      }}
                      className="w-5 h-5 bg-blue-600 hover:bg-blue-700 rounded-full flex items-center justify-center text-white text-[10px] cursor-pointer"
                      title="Accept"
                    >
                      ✓
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDeclineRequestSidebar(req);
                      }}
                      className="w-5 h-5 bg-slate-200 hover:bg-slate-300 rounded-full flex items-center justify-center text-slate-500 text-[10px] cursor-pointer"
                      title="Decline"
                    >
                      ×
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </aside>

      {/* BOTTOM NAV: Mobile-only */}
      {!state.selectedPostId && !state.selectedChatId && state.activeStoryIndex === null && state.currentView !== 'create_post' && (
        <BottomNav
          currentView={state.currentView}
          onChangeView={changeView}
          unreadNotificationsCount={unreadNotifications}
          unreadChatsCount={unreadChats}
        />
      )}

      {/* MOBILE DRAWER (Sidebar Connection / Quick Access Panel for Mobile and Tablet) */}
      {isMobileDrawerOpen && (
        <div className="fixed inset-0 z-50 flex justify-end md:hidden animate-fade-in" id="mobile_drawer_overlay">
          {/* Backdrop overlay */}
          <div 
            className="absolute inset-0 bg-slate-900/40 backdrop-blur-xs transition-opacity duration-300"
            onClick={() => setIsMobileDrawerOpen(false)}
          />
          {/* Drawer Sheet Body */}
          <div className="relative w-80 h-full bg-slate-50 text-slate-900 shadow-2xl flex flex-col z-10 animate-slide-left border-l border-slate-200">
            {/* Header */}
            <div className="p-4 bg-white border-b border-slate-150 flex items-center justify-between shrink-0">
              <div className="flex items-center space-x-2">
                <div className="w-7 h-7 bg-blue-50 text-blue-600 rounded-lg flex items-center justify-center font-bold text-xs ring-2 ring-blue-100">IB</div>
                <h2 className="text-sm font-black text-slate-800 tracking-tight">Connections & Activity</h2>
              </div>
              <button 
                onClick={() => setIsMobileDrawerOpen(false)}
                className="p-1.5 hover:bg-slate-100 text-slate-400 rounded-lg cursor-pointer hover:text-slate-600 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Scrollable contents */}
            <div className="flex-grow overflow-y-auto p-4 space-y-6">
              
              {/* Active Profile Info */}
              {userProfile && (
                <div 
                  className="bg-white p-3.5 rounded-2xl border border-slate-150 shadow-xs flex items-center justify-between cursor-pointer hover:bg-slate-50 transition"
                  onClick={() => {
                    handleSelectUser(userProfile.uid);
                    setIsMobileDrawerOpen(false);
                  }}
                >
                  <div className="flex items-center space-x-3 min-w-0">
                    <div className="w-10 h-10 rounded-full border border-slate-100 overflow-hidden bg-slate-50 shrink-0">
                      <img src={userProfile.photoURL || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&h=150'} alt="" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                    </div>
                    <div className="truncate text-left leading-tight">
                      <h4 className="font-bold text-xs text-slate-800 truncate">{userProfile.name}</h4>
                      <p className="text-[10px] text-slate-450 truncate mt-0.5">@{userProfile.username}</p>
                    </div>
                  </div>
                  <span className="text-[9.5px] text-blue-600 bg-blue-50/80 px-2 py-0.5 rounded-md font-bold select-none leading-none">View</span>
                </div>
              )}

              {/* Friend Connection Requests */}
              <div className="space-y-2.5">
                <h3 className="text-[10px] font-black uppercase tracking-wider text-slate-450 flex items-center justify-between">
                  <span>Friend Requests</span>
                  <span className="bg-slate-200/80 text-slate-600 px-1.5 py-0.5 rounded-md text-[9px] font-bold">{rightSidebarFriendRequests.length}</span>
                </h3>
                {rightSidebarFriendRequests.length === 0 ? (
                  <div className="bg-white/80 p-5 rounded-2xl border border-dotted border-slate-200 text-center text-[10.5px] text-slate-400 font-semibold py-8">
                    No pending friend requests
                  </div>
                ) : (
                  <div className="space-y-2">
                    {rightSidebarFriendRequests.map((req) => (
                      <div key={req.id} className="flex items-center justify-between bg-white p-2.5 rounded-xl border border-slate-150 shadow-xs">
                        <div className="flex items-center space-x-2.5 min-w-0">
                          <div className="w-8 h-8 rounded-full overflow-hidden bg-slate-100 border border-slate-200 shrink-0">
                            <img src={req.senderPhoto || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&h=150'} alt="" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                          </div>
                          <div className="truncate min-w-0 text-left">
                            <p className="text-[10.5px] font-bold text-slate-800 truncate leading-tight">{req.senderName}</p>
                            <p className="text-[9px] text-slate-450 truncate leading-none">@{req.senderUsername}</p>
                          </div>
                        </div>
                        <div className="flex space-x-1.5 shrink-0">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleAcceptRequestSidebar(req);
                            }}
                            className="w-6 h-6 bg-blue-600 hover:bg-blue-700 active:scale-90 text-white rounded-full flex items-center justify-center text-[11px] font-extrabold cursor-pointer transition shadow-xs shadow-blue-200"
                            title="Accept"
                          >
                            ✓
                          </button>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleDeclineRequestSidebar(req);
                            }}
                            className="w-6 h-6 bg-slate-200 hover:bg-slate-300 active:scale-90 text-slate-500 rounded-full flex items-center justify-center text-[11px] font-extrabold cursor-pointer transition"
                            title="Decline"
                          >
                            ×
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Recent Direct Messages */}
              <div className="space-y-2.5">
                <div className="flex items-center justify-between">
                  <h3 className="text-[10px] font-black uppercase tracking-wider text-slate-450">Active Chats</h3>
                  <button 
                    onClick={() => {
                      changeView('messages');
                      setIsMobileDrawerOpen(false);
                    }} 
                    className="text-[9px] text-blue-600 font-bold hover:underline"
                  >
                    View All
                  </button>
                </div>
                {rightSidebarChats.filter(chat => {
                  const friendId = chat.id.split('_').find(p => p !== currentUser?.uid);
                  return friendId ? !blockedUserIds.includes(friendId) : true;
                }).length === 0 ? (
                  <div className="bg-white/80 p-5 rounded-2xl border border-dotted border-slate-200 text-center text-[10.5px] text-slate-400 font-semibold py-8 animate-pulse">
                    No active chats. Start messaging!
                  </div>
                ) : (
                  <div className="space-y-1.5">
                    {rightSidebarChats
                      .filter(chat => {
                        const friendId = chat.id.split('_').find(p => p !== currentUser?.uid);
                        return friendId ? !blockedUserIds.includes(friendId) : true;
                      })
                      .slice(0, 4)
                      .map((chat) => (
                      <div
                        key={chat.id}
                        onClick={() => {
                          setState((prev) => ({
                            ...prev,
                            currentView: 'messages',
                            selectedChatId: chat.id,
                            selectedUserId: null,
                          }));
                          setIsMobileDrawerOpen(false);
                        }}
                        className="flex items-center space-x-2.5 p-2 bg-white hover:bg-slate-50 border border-slate-100 rounded-xl transition cursor-pointer text-left"
                      >
                        <div className="relative shrink-0">
                          <div className="w-8 h-8 rounded-full bg-slate-100 overflow-hidden border border-slate-200 flex items-center justify-center">
                            {chat.friendPhoto ? (
                              <img src={chat.friendPhoto} alt="" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                            ) : (
                              <UserIcon className="w-3.5 h-3.5 text-slate-400" />
                            )}
                          </div>
                          <div className="absolute bottom-0 right-0 w-2 h-2 bg-green-500 rounded-full border border-white"></div>
                        </div>
                        <div className="flex-1 min-w-0 leading-snug">
                          <p className="text-[10px] font-bold text-slate-800 truncate">{chat.friendName || 'Social User'}</p>
                          <p className="text-[9px] text-slate-400 truncate mt-0.5">{chat.lastMessage}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Safety & Blocks Shortcut */}
              <div className="space-y-2.5">
                <h3 className="text-[10px] font-black uppercase tracking-wider text-slate-450">Settings & Safety</h3>
                <button
                  onClick={() => {
                    handleSelectUser(currentUser.uid);
                    setIsMobileDrawerOpen(false);
                  }}
                  className="w-full p-3 bg-red-50/40 hover:bg-red-50 hover:text-red-700 hover:border-red-200 border border-red-100 rounded-xl transition flex items-center space-x-2 text-red-600 text-left font-bold text-[10.5px] cursor-pointer"
                >
                  <ShieldAlert className="w-4 h-4 text-red-500 shrink-0 animate-pulse" />
                  <span>Blocked Users Configuration ({myBlockedUsers.length})</span>
                </button>
              </div>

            </div>

            {/* Account Signout Sheet Footer */}
            <div className="p-4 bg-white border-t border-slate-150 shrink-0">
              <button
                onClick={() => {
                  if (window.confirm('Are you sure you want to log out?')) {
                    import('firebase/auth').then(({ signOut }) => signOut(auth));
                  }
                }}
                className="w-full py-2.5 px-4 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-xl text-xs font-bold transition cursor-pointer select-none"
              >
                Sign Out Account
              </button>
              <p className="text-[9px] text-slate-400 mt-2 font-mono text-center">Instabook Applet © 2026</p>
            </div>
          </div>
          
          {/* Core Animation Rules for Backdrop Fade and Sheet Slide */}
          <style>{`
            @keyframes fadeIn {
              from { opacity: 0; }
              to { opacity: 1; }
            }
            @keyframes slideLeft {
              from { transform: translateX(100%); }
              to { transform: translateX(0); }
            }
            .animate-fade-in {
              animation: fadeIn 0.2s cubic-bezier(0.16, 1, 0.3, 1) forwards;
            }
            .animate-slide-left {
              animation: slideLeft 0.25s cubic-bezier(0.16, 1, 0.3, 1) forwards;
            }
          `}</style>
        </div>
      )}
    </div>
  );
}
