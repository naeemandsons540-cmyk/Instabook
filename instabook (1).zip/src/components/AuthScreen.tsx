import React, { useState } from 'react';
import { signInWithPopup, signInWithEmailAndPassword, createUserWithEmailAndPassword, signInAnonymously } from 'firebase/auth';
import { auth, googleProvider } from '../firebase';
import { BookOpen, Chrome, Lock, Mail, AlertTriangle, Info, UserCheck } from 'lucide-react';
import { motion } from 'motion/react';

interface AuthScreenProps {
  onCheckingUser: (loading: boolean) => void;
}

export function AuthScreen({ onCheckingUser }: AuthScreenProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [infoMsg, setInfoMsg] = useState<string | null>(null);

  const handleGoogleLogin = async () => {
    setErrorMsg(null);
    setInfoMsg(null);
    setLoading(true);
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || 'Google Sign-In failed.');
    } finally {
      setLoading(false);
    }
  };

  const handleAnonymousLogin = async () => {
    setErrorMsg(null);
    setInfoMsg(null);
    setLoading(true);
    try {
      await signInAnonymously(auth);
      setInfoMsg('Logged in anonymously!');
    } catch (err: any) {
      console.error(err);
      if (err.code === 'auth/operation-not-allowed') {
        setErrorMsg('Anonymous login is not enabled in your Firebase console. Please enable it under Authentication > Sign-in method, or use Email/Google Sign-In.');
      } else {
        setErrorMsg(err.message || 'Anonymous Sign-In failed.');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      setErrorMsg('Please supply both email and password.');
      return;
    }
    if (password.length < 6) {
      setErrorMsg('Password should be at least 6 characters.');
      return;
    }

    setErrorMsg(null);
    setInfoMsg(null);
    setLoading(true);

    try {
      // 1. Attempt login
      await signInWithEmailAndPassword(auth, email, password);
    } catch (err: any) {
      // 2. Auto-registers if user is not found or credentials invalid as registration fallback
      const code = err.code;
      if (code === 'auth/user-not-found' || code === 'auth/invalid-credential') {
        setInfoMsg('Checking credentials... Initiating auto-registration fallback...');
        try {
          await createUserWithEmailAndPassword(auth, email, password);
          setInfoMsg('Successfully registered and logged in!');
        } catch (regErr: any) {
          console.error(regErr);
          if (regErr.code === 'auth/operation-not-allowed') {
            setErrorMsg('Email/Password sign-in is not enabled in your Firebase console. Please use Google Login or enable Email provider.');
          } else {
            setErrorMsg(regErr.message || 'Auto-registration failed.');
          }
        }
      } else if (code === 'auth/operation-not-allowed') {
        setErrorMsg('Email/Password auth is not enabled yet in your Firebase console. Please enable it or sign in with Google.');
      } else {
        console.error(err);
        setErrorMsg(err.message || 'Login attempt failed.');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col justify-between px-4 py-8 font-sans" id="auth_container">
      {/* Upper Brand Section */}
      <div className="flex-1 flex flex-col justify-center items-center max-w-sm mx-auto w-full">
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.5 }}
          className="bg-blue-600 text-white p-5 rounded-3xl shadow-xl shadow-blue-500/20 mb-6 flex items-center justify-center"
          id="app_logo_hero"
        >
          <BookOpen className="w-12 h-12 stroke-[2.5]" />
        </motion.div>

        <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight text-center" id="app_title">
          Instabook
        </h1>
        <p className="text-slate-500 text-center text-sm mt-2 max-w-[280px]">
          A complete, mobile-first social media experience to connect with your friends.
        </p>

        {/* Form Box */}
        <motion.form
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
          onSubmit={handleEmailAuth}
          className="mt-10 w-full"
          id="auth_form"
        >
          <div className="space-y-4">
            <div className="relative">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
                <Mail className="w-5 h-5" />
              </span>
              <input
                id="input_email"
                type="email"
                required
                placeholder="Email Address"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full pl-10 pr-4 py-3 bg-white border border-slate-200 rounded-xl outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition text-slate-900 text-sm"
              />
            </div>

            <div className="relative">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
                <Lock className="w-5 h-5" />
              </span>
              <input
                id="input_password"
                type="password"
                required
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full pl-10 pr-4 py-3 bg-white border border-slate-200 rounded-xl outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition text-slate-900 text-sm"
              />
            </div>
          </div>

          {errorMsg && (
            <div className="mt-4 p-3 bg-rose-50 border border-rose-100 rounded-xl flex items-start gap-2 text-rose-700 text-xs shadow-sm" id="auth_error">
              <AlertTriangle className="w-4 h-4 mt-0.5 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {infoMsg && (
            <div className="mt-4 p-3 bg-blue-50 border border-blue-100 rounded-xl flex items-start gap-2 text-blue-700 text-xs shadow-sm" id="auth_info">
              <Info className="w-4 h-4 mt-0.5 shrink-0" />
              <span>{infoMsg}</span>
            </div>
          )}

          <button
            id="btn_email_login"
            type="submit"
            disabled={loading}
            className="w-full mt-6 py-3.5 bg-blue-600 text-white rounded-xl font-semibold text-sm shadow-md shadow-blue-600/10 hover:bg-blue-700 active:bg-blue-800 transition disabled:opacity-50"
          >
            {loading ? 'Authenticating...' : 'Log In / Register'}
          </button>
        </motion.form>

        {/* Divider */}
        <div className="relative flex py-5 items-center w-full">
          <div className="flex-grow border-t border-slate-200"></div>
          <span className="flex-shrink mx-4 text-slate-400 text-xs uppercase font-medium tracking-wider">or</span>
          <div className="flex-grow border-t border-slate-200"></div>
        </div>

        {/* Google Authentication */}
        <button
          id="btn_google_login"
          type="button"
          onClick={handleGoogleLogin}
          disabled={loading}
          className="w-full py-3.5 bg-white text-slate-700 border border-slate-200 rounded-xl shadow-sm text-sm font-semibold flex items-center justify-center gap-3 hover:bg-slate-50 active:bg-slate-100 transition disabled:opacity-50 cursor-pointer"
        >
          <Chrome className="w-5 h-5 text-rose-500" />
          <span>Continue with Google</span>
        </button>

        {/* Demo Guest Authentication Fallback */}
        <button
          id="btn_guest_login"
          type="button"
          onClick={handleAnonymousLogin}
          disabled={loading}
          className="w-full mt-3 py-3.5 bg-slate-800 text-white rounded-xl shadow-sm text-sm font-semibold flex items-center justify-center gap-3 hover:bg-slate-900 active:bg-slate-950 transition disabled:opacity-50 cursor-pointer"
        >
          <UserCheck className="w-5 h-5 text-emerald-400" />
          <span>Demo / Guest Sign In</span>
        </button>
      </div>

      {/* Mini Helper Footer */}
      <div className="text-center text-[11px] text-slate-400 max-w-xs mx-auto mt-8">
        If using email login for the first time, check that Email provider is enabled in your Firebase Auth dashboard. Enjoy the full Instabook speed.
      </div>
    </div>
  );
}
