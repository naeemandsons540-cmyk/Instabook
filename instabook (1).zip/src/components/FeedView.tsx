import React, { useEffect, useState } from 'react';
import { Post, Story, UserProfile } from '../types';
import { collection, query, orderBy, onSnapshot, getDocs, doc, setDoc, getDoc } from 'firebase/firestore';
import { db, auth, OperationType, handleFirestoreError } from '../firebase';
import { StoryBubble } from './StoryBubble';
import { PostCard } from './PostCard';
import { BookOpen, AlertCircle, Plus, Send } from 'lucide-react';
import { motion } from 'motion/react';
import { uploadImage } from '../utils/image';

interface FeedViewProps {
  currentUserProfile: UserProfile | null;
  onSelectPost: (postId: string) => void;
  onSelectUser: (userId: string) => void;
  onSelectStoryGroup: (index: number) => void;
  onCreatePostClick: () => void;
  groupedStories: { authorId: string; stories: Story[] }[];
  blockedUserIds?: string[];
}

// Predefined Sponsored Adsterra Ads to seed in Firestore
const SPONSORED_ADS_TEMPLATES = [
  {
    id: 'ad_1',
    authorId: 'adsterra_official',
    authorName: 'Adsterra Official',
    authorPhotoURL: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=100&h=100',
    authorUsername: 'adsterra_official',
    content: '[Sponsored] Monetize your website traffic globally with Adsterra! Over 30K partners turn 1.3B+ daily impressions into high revenue payouts with SmartCPM solutions. Join our family today!',
    imageURL: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=600&h=400',
    likesCount: 549,
    commentsCount: 12,
    isSponsored: true
  },
  {
    id: 'ad_2',
    authorId: 'adsterra_official',
    authorName: 'Adsterra Official',
    authorPhotoURL: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=100&h=100',
    authorUsername: 'adsterra_official',
    content: '[Sponsored] Launch targeted premium popunder, social bar, or banner ad campaigns with Adsterra. Connect directly with over 20K absolute advertisers and enjoy flawless fraud-free traffic converting around the clock!',
    imageURL: 'https://images.unsplash.com/photo-1551836022-d5d88e9218df?auto=format&fit=crop&w=600&h=400',
    likesCount: 320,
    commentsCount: 4,
    isSponsored: true
  }
];

export function FeedView({
  currentUserProfile,
  onSelectPost,
  onSelectUser,
  onSelectStoryGroup,
  onCreatePostClick,
  groupedStories,
  blockedUserIds = [],
}: FeedViewProps) {
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [storyUploading, setStoryUploading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // 1. Seed or Fetch Predefined Sponsored Ads in Firestore on load
  // Doing so guarantees that ad posts have active, persistent docs for likes and comments!
  useEffect(() => {
    const seedAdsAndListen = async () => {
      try {
        for (const ad of SPONSORED_ADS_TEMPLATES) {
          const adRef = doc(db, 'posts', ad.id);
          const snap = await getDoc(adRef);
          
          if (!snap.exists()) {
            await setDoc(adRef, {
              ...ad,
              createdAt: new Date() // Seeding with standard Timestamp
            });
          }
        }
      } catch (err) {
        console.error('Failed to seed sponsored ads in database:', err);
      }
    };
    seedAdsAndListen();
  }, []);

  // 2. Fetch all feed posts sorted by date
  useEffect(() => {
    const pCol = collection(db, 'posts');
    const q = query(pCol, orderBy('createdAt', 'desc'));

    const unsub = onSnapshot(q, (snapshot) => {
      const allPosts: Post[] = [];
      snapshot.forEach((doc) => {
        allPosts.push({ id: doc.id, ...doc.data() } as Post);
      });

      // Filter out Ad templates and blocked authors from normal sorting, to manually insert them exactly after every 2 regular posts!
      const regularPosts = allPosts.filter(p => !p.id.startsWith('ad_') && !blockedUserIds.includes(p.authorId));
      const adPostsInDb = allPosts.filter(p => p.id.startsWith('ad_'));

      // If no ad posts were returned from Firestore snapshot yet, we fallback to static templates
      const adsList = adPostsInDb.length > 0 ? adPostsInDb : SPONSORED_ADS_TEMPLATES.map(a => ({ ...a, createdAt: new Date() }));

      // Mix 1 ad post after every 2 regular posts
      const mixed: Post[] = [];
      let adIndex = 0;

      for (let i = 0; i < regularPosts.length; i++) {
        mixed.push(regularPosts[i]);
        
        // After every 2 regular posts, insert an ad post
        if ((i + 1) % 2 === 0 && adsList.length > 0) {
          const currentAd = adsList[adIndex % adsList.length];
          mixed.push({
            ...currentAd,
            isSponsored: true
          } as Post);
          adIndex++;
        }
      }

      setPosts(mixed);
      setLoading(false);
    }, (err) => {
      console.error(err);
      handleFirestoreError(err, OperationType.GET, 'posts');
    });

    return () => unsub();
  }, [blockedUserIds]);

  // 3. Upload a new story
  const handleStoryUpload = async (file: File) => {
    const user = auth.currentUser;
    if (!user || !currentUserProfile) return;

    setStoryUploading(true);
    setErrorMsg(null);

    try {
      // Compress and upload image
      const storyImageURL = await uploadImage(file);

      const pathForStory = 'stories';
      const storyId = `${user.uid}_story_${Date.now()}`;
      const payload: Story = {
        id: storyId,
        authorId: user.uid,
        authorName: currentUserProfile.name,
        authorPhotoURL: currentUserProfile.photoURL,
        authorUsername: currentUserProfile.username,
        imageURL: storyImageURL,
        createdAt: new Date()
      };

      await setDoc(doc(db, 'stories', storyId), payload);
    } catch (err: any) {
      console.error(err);
      handleFirestoreError(err, OperationType.WRITE, 'stories');
      setErrorMsg(err.message || 'Failed to upload story.');
    } finally {
      setStoryUploading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 pb-20 font-sans" id="feed_view_root">
      {/* Brand Navigation Header */}
      <header className="sticky top-0 bg-white border-b border-slate-100 flex items-center justify-between px-4 h-14 z-30 shadow-sm lg:hidden" id="feed_header">
        <div className="flex items-center gap-2">
          <BookOpen className="w-6 h-6 text-blue-600 stroke-[2.2]" />
          <h1 className="font-extrabold text-slate-900 text-lg tracking-tight">Instabook</h1>
        </div>
        <div className="flex items-center gap-2">
          {/* Quick upload story helper info button */}
          <span className="text-[10px] font-bold text-slate-400 bg-slate-50 px-2 py-0.5 rounded-full border border-slate-100 uppercase tracking-widest hidden sm:inline">PWA Social Hub</span>
        </div>
      </header>

      {/* Stories horizontal conveyor bar */}
      <div className="bg-white py-3 border-b border-slate-100 mb-3" id="stories_box">
        <StoryBubble
          currentUserProfile={currentUserProfile}
          groupedStories={groupedStories.filter(group => !blockedUserIds.includes(group.authorId))}
          onSelectStoryGroup={onSelectStoryGroup}
          onUploadStory={handleStoryUpload}
          isUploading={storyUploading}
        />
        {errorMsg && (
          <div className="px-4 py-2 bg-rose-50 border-t border-rose-100 flex items-center gap-2 text-rose-700 text-xs mt-2" id="feed_error_banner">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}
      </div>

      {/* Main post scroll feeds */}
      <main className="max-w-md lg:max-w-4xl mx-auto px-4 lg:px-0 space-y-4" id="posts_feed_scroller">
        {loading ? (
          <div className="flex flex-col items-center justify-center py-20 text-slate-400 gap-2" id="feed_posts_loading_box">
            <span className="w-8 h-8 rounded-full border-4 border-blue-500 border-t-transparent animate-spin"></span>
            <span className="text-slate-400 text-xs font-semibold">Loading feed posts...</span>
          </div>
        ) : posts.length === 0 ? (
          <div className="flex flex-col items-center justify-center p-8 bg-white border border-slate-100 rounded-2xl text-center text-slate-400 py-16 gap-3" id="empty_post_prompt">
            <BookOpen className="w-12 h-12 stroke-[1.2] text-slate-300" />
            <h3 className="font-bold text-sm text-slate-800">Your feed is currently empty</h3>
            <p className="text-xs max-w-xs justify-center align-middle">Be the first to share an image, thoughts, or video! Tap the button below to outline your first post.</p>
            <button
              onClick={onCreatePostClick}
              className="mt-2 py-2 px-4 bg-blue-600 text-white rounded-xl text-xs font-bold shadow-md hover:bg-blue-700 transition cursor-pointer"
            >
              Draft First Post
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5" id="posts_lists_box">
            {posts.map((post) => (
              <PostCard
                key={post.id}
                post={post}
                onSelectPost={onSelectPost}
                onSelectUser={onSelectUser}
              />
            ))}
          </div>
        )}
      </main>

      {/* Floating Action Button for post creation */}
      <button
        id="feed_fab_btn"
        onClick={onCreatePostClick}
        className="fixed bottom-20 right-4 p-4 bg-blue-600 text-white rounded-full shadow-lg shadow-blue-500/30 hover:bg-blue-700 active:scale-95 transition cursor-pointer z-35 shrink-0 lg:hidden"
      >
        <Plus className="w-6 h-6 stroke-[2.5]" />
      </button>
    </div>
  );
}
