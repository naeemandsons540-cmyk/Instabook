# Security Specification & Threat Model (Instabook)

This document formalizes the security invariants, threat model, and validation gates for the Instabook database architecture, adhering to zero-trust design principles.

## 1. Data Invariants

1. **User Identity Isolation**: A user's profile inside `/users/{userId}` can only be created or modified if their authenticated UID matches `userId`.
2. **Adsterra Reserved Boundary**: User registration and edit profiles must reject usernames containing the case-insensitive or exact phrase `"Adsterra Official"`.
3. **Temporal Validity**: Creation timestamps (`createdAt`) and update timestamps (`updatedAt`) must strictly match `request.time`.
4. **Chat Participant Isolation**: Reading, updating, or writing messages within a chat thread is strictly restricted to authenticated users listed in the direct `participants` array.
5. **Private Notifications**: A user's notification list under `/users/{userId}/notifications/{notificationId}` is readable solely by the owning `userId`.
6. **No Blank Posts**: Posts must contain at least a layout combination of either `content` text, `imageURL`, or a parsed `videoURL`. Complete empty writes are forbidden.

---

## 2. The "Dirty Dozen" Threat Payloads

Below is the verification list of 12 critical exploit vectors that our security rules are structured to block with `PERMISSION_DENIED`:

1. **UID Spoofing**: Authenticated user `attacker_123` attempts to write profile data to `/users/victim_uid`.
2. **Reserved Username Hijack**: Registering username `"Adsterra Official"` to piggyback on system credibility.
3. **Privilege Escalation**: Attempting to insert a custom `"isAdmin": true` claim or field within the user payload.
4. **Denial of Wallet (ID Injection)**: Injecting a 2MB hexadecimal string as a target document ID (blocked by `isValidId()` limits).
5. **Shadow Field Injection**: Writing posts containing unauthorized state variables like `likesCount: 9999` directly from the client.
6. **Immutable Field Modification**: A contributor attempting to change their `authorId` or `createdAt` on an existing post.
7. **Empty Post Spam**: Submitting a post document where `content`, `imageURL`, and `videoURL` are all null/blank.
8. **Chat Eavesdropping**: Scanning `/chats/{vic_chat}/messages` when the requester's UID is not in the chat's participant list.
9. **Notification Hijacking**: Reader attempting to lists notifications belonging to another user's sub-collection `/users/victim_user/notifications`.
10. **Untrusted Client Timestamps**: Client passing custom epoch millisecond times as `createdAt` to gain seniority in chronological lists.
11. **Double Likers Injection**: Creating multiple like documents or direct write operations to inject random likes counts.
12. **Orphaned Friend Connections**: Setting up friendship indicators `/users/{user}/friends/{friend}` without completing mutual requests validation.

*(Included for testing compliance against the security posture rules)*
