export interface UserProfile {
  uid: string;
  name: string;
  username: string;
  photoURL: string;
  dob: string;
  gender: string;
  createdAt: any; // Firestore Timestamp
  friendsCount: number;
  adEarnings?: number;
  adClicks?: number;
  adImpressions?: number;
}

export interface Post {
  id: string;
  authorId: string;
  authorName: string;
  authorPhotoURL: string;
  authorUsername: string;
  content?: string;
  imageURL?: string;
  videoURL?: string;
  likesCount: number;
  commentsCount: number;
  createdAt: any; // Firestore Timestamp
  isSponsored?: boolean; // Client-side or ad-injected field
}

export interface Story {
  id: string;
  authorId: string;
  authorName: string;
  authorPhotoURL: string;
  authorUsername: string;
  imageURL: string;
  createdAt: any; // Firestore Timestamp
}

export interface Comment {
  id: string;
  postId: string;
  authorId: string;
  authorName: string;
  authorPhotoURL: string;
  authorUsername: string;
  content: string;
  createdAt: any; // Firestore Timestamp
}

export interface FriendRequest {
  id: string;
  senderId: string;
  senderName: string;
  senderPhoto: string;
  senderUsername: string;
  receiverId: string;
  status: 'pending' | 'accepted' | 'declined';
  createdAt: any; // Firestore Timestamp
}

export interface Notification {
  id: string;
  actorId: string;
  actorName: string;
  actorPhotoURL: string;
  type: 'like' | 'comment' | 'friend_request' | 'friend_accept';
  postId?: string;
  text: string;
  isRead: boolean;
  createdAt: any; // Firestore Timestamp;
}

export interface Chat {
  id: string;
  participants: string[];
  lastMessage: string;
  lastMessageSenderId: string;
  lastMessageTime: any; // Firestore Timestamp
}

export interface Message {
  id: string;
  chatId: string;
  senderId: string;
  senderName: string;
  senderPhoto: string;
  content: string;
  createdAt: any; // Firestore Timestamp
}

export type ViewType = 'feed' | 'search' | 'create_post' | 'messages' | 'notifications' | 'profile';

export interface AppState {
  currentView: ViewType;
  selectedPostId: string | null;
  selectedChatId: string | null;
  selectedUserId: string | null; // For viewing other users' profiles
  activeStoryIndex: number | null; // Index of the selected story to view
  storiesList: { authorId: string; stories: Story[] }[]; // Grouped stories
}
