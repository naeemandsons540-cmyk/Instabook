import React, { useState } from 'react';
import { collection, query, where, getDocs, doc, setDoc } from 'firebase/firestore';
import { db, auth, OperationType, handleFirestoreError } from '../firebase';
import { uploadImage } from '../utils/image';
import { Camera, User, Calendar, Sliders, CheckCircle2, XCircle } from 'lucide-react';
import { motion } from 'motion/react';

interface OnboardingScreenProps {
  onComplete: (profile: any) => void;
}

export function OnboardingScreen({ onComplete }: OnboardingScreenProps) {
  const [name, setName] = useState('');
  const [username, setUsername] = useState('');
  const [dob, setDob] = useState('');
  const [gender, setGender] = useState('rather-not-say');
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [checkingUsername, setCheckingUsername] = useState(false);
  const [usernameStatus, setUsernameStatus] = useState<'available' | 'taken' | 'reserved' | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Auto-generate a starter username from the email or random characters
  React.useEffect(() => {
    const user = auth.currentUser;
    if (user) {
      if (user.displayName) setName(user.displayName);
      if (user.photoURL) setImagePreview(user.photoURL);
      
      const seed = user.email ? user.email.split('@')[0] : '';
      if (seed) {
        const cleanSeed = seed.replace(/[^a-zA-Z0-9_.]/g, '').toLowerCase();
        setUsername(cleanSeed);
      }
    }
  }, []);

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (!file.type.startsWith('image/')) {
        setErrorMsg('Invalid file type. Please select an image image.');
        return;
      }
      setImageFile(file);
      const url = URL.createObjectURL(file);
      setImagePreview(url);
    }
  };

  const validateUsernameText = (val: string) => {
    const cleaned = val.replace(/\s+/g, '').replace(/[^a-zA-Z0-9_.]/g, '');
    setUsername(cleaned);

    const norm = cleaned.toLowerCase().trim();
    if (norm === 'adsterra official' || norm.includes('adsterra')) {
      setUsernameStatus('reserved');
      return;
    }
    if (cleaned.length < 3) {
      setUsernameStatus(null);
      return;
    }
    checkUsernameUniqueness(cleaned);
  };

  const checkUsernameUniqueness = async (uName: string) => {
    setCheckingUsername(true);
    try {
      const q = query(collection(db, 'users'), where('username', '==', uName));
      const res = await getDocs(q);
      
      // Filter out own profile if somehow matching
      const matches = res.docs.filter(d => d.id !== auth.currentUser?.uid);
      if (matches.length > 0) {
        setUsernameStatus('taken');
      } else {
        setUsernameStatus('available');
      }
    } catch (err) {
      console.error('Failed checking username uniqueness', err);
    } finally {
      setCheckingUsername(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || name.trim().length === 0) {
      setErrorMsg('Please specify your physical display name.');
      return;
    }
    if (!username || username.length < 3) {
      setErrorMsg('Username must be at least 3 characters.');
      return;
    }
    if (usernameStatus === 'taken') {
      setErrorMsg('This username is already taken by another account.');
      return;
    }
    if (usernameStatus === 'reserved') {
      setErrorMsg('The username "Adsterra Official" or containing Adsterra is reserved and cannot be selected.');
      return;
    }
    if (!dob) {
      setErrorMsg('Please select your Date of Birth.');
      return;
    }

    setSubmitting(true);
    setErrorMsg(null);

    const user = auth.currentUser;
    if (!user) {
      setErrorMsg('Authentication session lost. Please log in again.');
      setSubmitting(false);
      return;
    }

    try {
      let finalPhotoURL = user.photoURL || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&h=150';

      // 1. Upload profile image via our compressed ImgBB API tool or Base64 fallback
      if (imageFile) {
        finalPhotoURL = await uploadImage(imageFile);
      } else if (imagePreview) {
        // If they already have a Google photo (which might be external), we use that.
        finalPhotoURL = imagePreview;
      }

      const path = `users/${user.uid}`;
      const payload = {
        uid: user.uid,
        name: name.trim(),
        username: username.toLowerCase().trim(),
        photoURL: finalPhotoURL,
        dob: dob,
        gender: gender,
        createdAt: new Date(), // Using Client JS Date matching Firebase Timestamp insertion
        friendsCount: 0
      };

      // Create profile document in Firestore
      await setDoc(doc(db, 'users', user.uid), payload);
      onComplete(payload);
    } catch (err: any) {
      console.error(err);
      handleFirestoreError(err, OperationType.WRITE, `users/${user?.uid}`);
      setErrorMsg(err.message || 'Failed saving your profile details.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4 font-sans" id="onboarding_container">
      <motion.div
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="bg-white rounded-3xl shadow-xl w-full max-w-md p-6 border border-slate-100"
        id="onboarding_card"
      >
        <div className="text-center mb-6">
          <h2 className="text-2xl font-bold text-slate-900 tracking-tight">Complete Profile</h2>
          <p className="text-slate-500 text-sm mt-1">Tell us a bit about yourself to enter Instabook.</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5" id="onboarding_form">
          {/* Avatar Picker */}
          <div className="flex flex-col items-center justify-center">
            <div className="relative">
              <div className="w-24 h-24 rounded-full border-4 border-slate-100 overflow-hidden bg-slate-100 flex items-center justify-center shadow-inner">
                {imagePreview ? (
                  <img src={imagePreview} alt="Preview" className="w-full h-full object-cover" id="avatar_preview" referrerPolicy="no-referrer" />
                ) : (
                  <User className="w-10 h-10 text-slate-400" />
                )}
              </div>
              <label className="absolute bottom-0 right-0 p-2 bg-blue-600 rounded-full text-white cursor-pointer hover:bg-blue-700 shadow-md transition shrink-0">
                <Camera className="w-4 h-4" />
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageChange}
                  className="hidden"
                  id="onboarding_image_input"
                />
              </label>
            </div>
            <span className="text-xs text-slate-400 mt-2">Upload Profile Photo</span>
          </div>

          {/* Display Name */}
          <div>
            <label className="block text-slate-700 text-xs font-semibold uppercase tracking-wider mb-2">Display Name</label>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 text-slate-400">
                <User className="w-4 h-4" />
              </span>
              <input
                id="onboarding_input_name"
                type="text"
                required
                placeholder="Tony Stark"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:bg-white focus:border-blue-500 transition text-slate-900 text-sm"
              />
            </div>
          </div>

          {/* Username */}
          <div>
            <label className="block text-slate-700 text-xs font-semibold uppercase tracking-wider mb-2">Unique Username</label>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 text-slate-400 font-medium text-sm">@</span>
              <input
                id="onboarding_input_username"
                type="text"
                required
                placeholder="tony_stark"
                value={username}
                onChange={(e) => validateUsernameText(e.target.value)}
                className="w-full pl-8 pr-10 py-2.5 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:bg-white focus:border-blue-500 transition text-slate-900 text-sm text-[lowercase]"
              />
              <span className="absolute inset-y-0 right-0 flex items-center pr-3">
                {checkingUsername && (
                  <span className="w-4 h-4 rounded-full border-2 border-blue-500 border-t-transparent animate-spin"></span>
                )}
                {!checkingUsername && usernameStatus === 'available' && (
                  <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                )}
                {!checkingUsername && (usernameStatus === 'taken' || usernameStatus === 'reserved') && (
                  <XCircle className="w-4 h-4 text-rose-500" />
                )}
              </span>
            </div>

            {/* Warning Labels */}
            {usernameStatus === 'taken' && (
              <p className="text-rose-500 text-xs mt-1">This username is taken.</p>
            )}
            {usernameStatus === 'reserved' && (
              <p className="text-rose-500 text-xs mt-1">"Adsterra Official" username is reserved.</p>
            )}
            {usernameStatus === 'available' && (
              <p className="text-emerald-600 text-xs mt-1">Username is available.</p>
            )}
          </div>

          {/* Date of Birth & Gender Grid */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-700 text-xs font-semibold uppercase tracking-wider mb-2">Birthdate</label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
                  <Calendar className="w-4 h-4" />
                </span>
                <input
                  id="onboarding_input_dob"
                  type="date"
                  required
                  value={dob}
                  onChange={(e) => setDob(e.target.value)}
                  className="w-full pl-9 pr-2 py-2.5 bg-slate-50 border border-slate-200 rounded-xl outline-none text-slate-900 text-sm focus:bg-white focus:border-blue-500 transition"
                />
              </div>
            </div>

            <div>
              <label className="block text-slate-700 text-xs font-semibold uppercase tracking-wider mb-2">Gender</label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
                  <Sliders className="w-4 h-4" />
                </span>
                <select
                  id="onboarding_input_gender"
                  value={gender}
                  onChange={(e) => setGender(e.target.value)}
                  className="w-full pl-9 pr-2 py-2.5 bg-slate-50 border border-slate-200 rounded-xl outline-none text-slate-900 text-sm focus:bg-white focus:border-blue-500 transition appearance-none cursor-pointer"
                >
                  <option value="rather-not-say">Rather not say</option>
                  <option value="male">Male</option>
                  <option value="female">Female</option>
                  <option value="other">Other</option>
                </select>
              </div>
            </div>
          </div>

          {errorMsg && (
            <div className="p-3 bg-rose-50 border border-rose-100 rounded-xl flex items-start gap-2 text-rose-700 text-xs" id="onboarding_error">
              <XCircle className="w-4 h-4 mt-0.5 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          <button
            id="onboarding_submit_btn"
            type="submit"
            disabled={submitting || checkingUsername || usernameStatus === 'taken' || usernameStatus === 'reserved'}
            className="w-full py-3 bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white rounded-xl font-bold text-sm shadow-md shadow-blue-500/15 transition disabled:opacity-50 cursor-pointer"
          >
            {submitting ? 'Creating Profile...' : 'Enter App'}
          </button>
        </form>
      </motion.div>
    </div>
  );
}
