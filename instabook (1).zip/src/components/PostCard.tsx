import React, { useState, useEffect } from 'react';
import { Post } from '../types';
import { ThumbsUp, MessageSquare, Share2, Eye, ShieldAlert } from 'lucide-react';
import { doc, setDoc, deleteDoc, getDoc, updateDoc, increment } from 'firebase/firestore';
import { db, auth, OperationType, handleFirestoreError } from '../firebase';
import { motion, AnimatePresence } from 'motion/react';

interface PostCardProps {
  key?: any;
  post: Post;
  onSelectPost: (postId: string) => void;
  onSelectUser: (userId: string) => void;
}

export function PostCard({ post, onSelectPost, onSelectUser }: PostCardProps) {
  const [isLiked, setIsLiked] = useState(false);
  const [likesCount, setLikesCount] = useState(post.likesCount);
  const [shareToast, setShareToast] = useState(false);
  const currentUid = auth.currentUser?.uid;

  const isSponsored = post.isSponsored || post.authorUsername.toLowerCase() === 'adsterra official' || post.id.startsWith('ad_');
  const [adState, setAdState] = useState<'idle' | 'redirecting' | 'viewing' | 'completed'>('idle');
  const [earnedDollar, setEarnedDollar] = useState<number>(0);
  const impressionLogged = React.useRef(false);

  // Monitor automated ad impressions for Sponsored Adsterra Ads
  useEffect(() => {
    if (!currentUid || !isSponsored || impressionLogged.current) return;
    
    let active = true;
    const logImpression = async () => {
      try {
        const userRef = doc(db, 'users', currentUid);
        const uSnap = await getDoc(userRef);
        if (uSnap.exists()) {
          const uData = uSnap.data();
          const currentEarnings = uData.adEarnings || 0;
          await updateDoc(userRef, {
            adImpressions: increment(1),
            adEarnings: Number((currentEarnings + 0.015).toFixed(4)) // $0.015 per impression view!
          });
          impressionLogged.current = true;
        }
      } catch (err) {
        console.error('Failed to register ad impression:', err);
      }
    };

    const timer = setTimeout(() => {
      if (active) {
        logImpression();
      }
    }, 1500);

    return () => {
      active = false;
      clearTimeout(timer);
    };
  }, [post.id, currentUid, isSponsored]);

  const handleAdClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!currentUid || !isSponsored) return;

    setAdState('redirecting');
    setTimeout(() => {
      setAdState('viewing');
    }, 1800);
  };

  const handleClaimAdReward = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!currentUid || !isSponsored) return;

    try {
      const userRef = doc(db, 'users', currentUid);
      const docSnap = await getDoc(userRef);
      if (docSnap.exists()) {
        const uData = docSnap.data();
        const currentEarnings = uData.adEarnings || 0;

        await updateDoc(userRef, {
          adClicks: increment(1),
          adEarnings: Number((currentEarnings + 0.25).toFixed(4)) // $0.25 per ad click!
        });
        setEarnedDollar(0.25);
        setAdState('completed');
      }
    } catch (err) {
      console.error('Failed to claim ad reward:', err);
      setAdState('idle');
    }
  };

  // Sync likes state
  useEffect(() => {
    if (!currentUid) return;
    const fetchLikeStatus = async () => {
      try {
        const likeRef = doc(db, 'posts', post.id, 'likes', currentUid);
        const snapshot = await getDoc(likeRef);
        setIsLiked(snapshot.exists());
      } catch (err) {
        console.error('Failed fetching like status:', err);
      }
    };
    fetchLikeStatus();
  }, [post.id, currentUid]);

  const handleLikeToggle = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!currentUid) return;

    const previousLiked = isLiked;
    const previousCount = likesCount;

    // Optimistic UI updates
    setIsLiked(!previousLiked);
    setLikesCount(previousCount + (previousLiked ? -1 : 1));

    const postRef = doc(db, 'posts', post.id);
    const likeRef = doc(db, 'posts', post.id, 'likes', currentUid);

    try {
      if (previousLiked) {
        // Dislike action
        await deleteDoc(likeRef);
        await updateDoc(postRef, {
          likesCount: increment(-1)
        });
      } else {
        // Like action
        await setDoc(likeRef, { uid: currentUid, timestamp: new Date() });
        await updateDoc(postRef, {
          likesCount: increment(1)
        });

        // Generate notification if owner is not own self
        if (post.authorId !== currentUid && !isSponsored) {
          let actorName = auth.currentUser?.displayName || 'Someone';
          let actorPhotoURL = auth.currentUser?.photoURL || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&h=150';

          try {
            const userDoc = await getDoc(doc(db, 'users', currentUid));
            if (userDoc.exists()) {
              const uData = userDoc.data();
              if (uData.name) actorName = uData.name;
              if (uData.photoURL) actorPhotoURL = uData.photoURL;
            }
          } catch (profileErr) {
            console.error('Failed to load like actor custom profile details:', profileErr);
          }

          const notificationId = `${currentUid}_like_${post.id}`;
          const notofRef = doc(db, 'users', post.authorId, 'notifications', notificationId);
          await setDoc(notofRef, {
            id: notificationId,
            actorId: currentUid,
            actorName: actorName,
            actorPhotoURL: actorPhotoURL,
            type: 'like',
            postId: post.id,
            text: 'liked your post',
            isRead: false,
            createdAt: new Date()
          });
        }
      }
    } catch (err: any) {
      // Revert optimism if fails
      setIsLiked(previousLiked);
      setLikesCount(previousCount);
      console.error(err);
      handleFirestoreError(err, OperationType.WRITE, `posts/${post.id}/likes/${currentUid}`);
    }
  };

  const handleShareClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    const appUrl = window.location.origin;
    const shareLink = `${appUrl}?post=${post.id}`;
    
    navigator.clipboard.writeText(shareLink).then(() => {
      setShareToast(true);
      setTimeout(() => setShareToast(false), 2200);
    }).catch(err => {
      console.error('Failed copying to clipboard', err);
    });
  };

  const getEmbedVideoSrc = (rawUrl: string) => {
    if (!rawUrl) return '';
    
    // Youtube URL check
    if (rawUrl.includes('youtube.com') || rawUrl.includes('youtu.be')) {
      const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/;
      const match = rawUrl.match(regExp);
      if (match && match[2].length === 11) {
        return `https://www.youtube.com/embed/${match[2]}`;
      }
    }

    // Google Drive URL check
    if (rawUrl.includes('drive.google.com')) {
      return rawUrl.replace('/view', '/preview').replace('/edit', '/preview');
    }

    return rawUrl;
  };

  // Convert Firestore dates safely
  const formatPublishedDate = (ts: any) => {
    if (!ts) return '';
    const date = ts.toDate ? ts.toDate() : new Date(ts);
    return date.toLocaleDateString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div
      onClick={() => onSelectPost(post.id)}
      className={`bg-white rounded-2xl border ${
        isSponsored ? 'border-amber-100 shadow-md shadow-amber-50/20' : 'border-slate-100'
      } p-4 relative flex flex-col gap-3 transition hover:shadow-md hover:border-slate-200/50 cursor-pointer select-none`}
      id={`post_card_${post.id}`}
    >
      {/* Post Header: Profile specs */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div
            onClick={(e) => {
              e.stopPropagation();
              if (!isSponsored) onSelectUser(post.authorId);
            }}
            className="w-10 h-10 rounded-full overflow-hidden bg-slate-100 shrink-0 border border-slate-100 cursor-pointer"
          >
            <img
              src={post.authorPhotoURL || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=80&h=80'}
              alt={post.authorName}
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          </div>

          <div>
            <div className="flex items-center gap-1.5">
              <span
                onClick={(e) => {
                  e.stopPropagation();
                  if (!isSponsored) onSelectUser(post.authorId);
                }}
                className="font-bold text-slate-900 text-sm hover:underline cursor-pointer"
              >
                {post.authorName}
              </span>
              {isSponsored && (
                <span className="bg-amber-100 text-amber-800 text-[9.5px] font-bold px-1.5 py-0.5 rounded-full flex items-center gap-0.5 shadow-sm">
                  Sponsored
                </span>
              )}
            </div>
            <div className="text-[11px] text-slate-400 font-medium">
              {isSponsored ? 'Sponsorship' : `@${post.authorUsername}`} • {formatPublishedDate(post.createdAt)}
            </div>
          </div>
        </div>

        {isSponsored && (
          <div className="p-1.5 bg-amber-50 rounded-full text-amber-600">
            <Eye className="w-4 h-4" />
          </div>
        )}
      </div>

      {/* Post Text content description */}
      {post.content && (
        <p className="text-slate-800 text-sm leading-relaxed whitespace-pre-wrap break-words">
          {post.content}
        </p>
      )}

      {/* Embedded Image Post Asset */}
      {post.imageURL && (
        <div className="w-full h-56 rounded-xl overflow-hidden bg-slate-50 border border-slate-100 relative">
          <img
            src={post.imageURL}
            alt="Asset"
            className="w-full h-full object-cover transition hover:scale-101 duration-300"
            referrerPolicy="no-referrer"
          />
        </div>
      )}

      {/* Embedded Video Link Render */}
      {post.videoURL && (
        <div className="w-full h-56 rounded-xl overflow-hidden bg-black border border-slate-100 relative shadow-inner">
          <iframe
            src={getEmbedVideoSrc(post.videoURL)}
            title="Video Attachment"
            className="w-full h-full border-none"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
            allowFullScreen
          />
        </div>
      )}

      {/* Stats row & Dividers */}
      {isSponsored && adState === 'idle' && (
        <button
          onClick={handleAdClick}
          className="w-full py-2.5 px-4 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-500 hover:to-amber-600 active:scale-98 text-amber-950 text-xs font-black rounded-xl cursor-pointer flex items-center justify-center gap-1.5 shadow-sm transition mt-1"
        >
          <span>🔥 Visit Sponsor & Earn $0.25 USD</span>
        </button>
      )}

      <div className="flex items-center justify-between text-xs text-slate-400 border-t border-slate-100 pt-3 mt-1 px-1">
        <div className="flex items-center gap-1">
          <div className="w-4.5 h-4.5 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center scale-90">
            <ThumbsUp className="w-2.5 h-2.5 fill-blue-600" />
          </div>
          <span className="font-semibold text-slate-700">{likesCount} likes</span>
        </div>

        <div className="font-medium hover:underline text-slate-500">
          {post.commentsCount} comments
        </div>
      </div>

      {/* Action Clicker buttons */}
      <div className="grid grid-cols-3 border-t border-slate-100 pt-1 mt-0.5">
        <button
          onClick={handleLikeToggle}
          className={`py-2 flex items-center justify-center gap-2 rounded-xl text-xs font-bold transition hover:bg-slate-50 active:bg-slate-100 cursor-pointer ${
            isLiked ? 'text-blue-600 scale-102 font-extrabold' : 'text-slate-600'
          }`}
          id={`btn_like_${post.id}`}
        >
          <ThumbsUp className={`w-4 h-4 ${isLiked ? 'fill-blue-600 stroke-blue-600' : ''}`} />
          <span>Like</span>
        </button>

        <button
          onClick={() => onSelectPost(post.id)}
          className="py-2 flex items-center justify-center gap-2 rounded-xl text-slate-600 text-xs font-bold transition hover:bg-slate-50 active:bg-slate-100 cursor-pointer"
          id={`btn_comment_${post.id}`}
        >
          <MessageSquare className="w-4 h-4" />
          <span>Comment</span>
        </button>

        <button
          onClick={handleShareClick}
          className="py-2 flex items-center justify-center gap-2 rounded-xl text-slate-600 text-xs font-bold transition hover:bg-slate-50 active:bg-slate-100 cursor-pointer relative"
          id={`btn_share_${post.id}`}
        >
          <Share2 className="w-4 h-4" />
          <span>Share</span>

          <AnimatePresence>
            {shareToast && (
              <motion.span
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="absolute bottom-full mb-2 bg-slate-900 text-white text-[10px] py-1 px-2.5 rounded-full z-30 shadow-md font-normal tracking-tight whitespace-nowrap"
              >
                Link copied to clipboard!
              </motion.span>
            )}
          </AnimatePresence>
        </button>
      </div>

      {/* Adsterra Interactive Simulation Overlay */}
      <AnimatePresence>
        {isSponsored && adState !== 'idle' && (
          <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4" onClick={(e) => e.stopPropagation()}>
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white rounded-3xl w-full max-w-md p-6 text-center border border-amber-200 relative shadow-2xl overflow-hidden flex flex-col items-center"
            >
              <div className="absolute top-0 inset-x-0 h-1.5 bg-gradient-to-r from-amber-400 via-orange-500 to-amber-400"></div>
              
              {adState === 'redirecting' && (
                <div className="py-8 space-y-4">
                  <div className="w-12 h-12 rounded-full border-4 border-amber-500 border-t-transparent animate-spin mx-auto"></div>
                  <div>
                    <h3 className="text-sm font-black text-slate-800 uppercase tracking-wider">Redirecting to Partner</h3>
                    <p className="text-[11px] text-slate-400 max-w-xs mx-auto mt-1 leading-normal font-medium">
                      Establishing highly secure monetization tunnel with Adsterra networks. Stand by to claim your revenue balance...
                    </p>
                  </div>
                </div>
              )}

              {adState === 'viewing' && (
                <div className="py-6 space-y-5 flex flex-col items-center w-full">
                  <div className="w-16 h-16 bg-amber-50 text-amber-500 rounded-2xl flex items-center justify-center text-2xl animate-bounce">🎁</div>
                  <div>
                    <h3 className="text-base font-extrabold text-slate-900 tracking-tight leading-snug">Adsterra Premium Partner Traffic</h3>
                    <p className="text-xs text-slate-500 mt-1.5 max-w-xs leading-normal">
                      Monetize traffic with premium smart rate payouts. Subscribe, explore, or signup to complete validation!
                    </p>
                  </div>
                  
                  <div className="bg-slate-50 border border-slate-150 p-3.5 rounded-2xl w-full text-left space-y-2">
                    <span className="text-[9px] bg-amber-100 text-amber-800 font-bold px-1.5 py-0.5 rounded-md uppercase tracking-widest leading-none">HOT CAMPAIGN</span>
                    <h4 className="font-extrabold text-xs text-slate-800 leading-tight">Install Pro VPN Secure & Save Your Speed</h4>
                    <p className="text-[10px] text-slate-450 leading-snug">The number #1 trusted high payout utility app recommended by Adsterra networks.</p>
                  </div>

                  <button
                    onClick={handleClaimAdReward}
                    className="w-full py-3 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white font-black text-xs rounded-xl shadow-lg shadow-amber-500/10 cursor-pointer active:scale-98 transition"
                  >
                    Confirm Visit & Credit $0.25 Reward!
                  </button>
                </div>
              )}

              {adState === 'completed' && (
                <div className="py-8 space-y-5 flex flex-col items-center">
                  <div className="w-16 h-16 bg-emerald-50 border border-emerald-100 text-emerald-500 rounded-full flex items-center justify-center text-3xl font-black">✓</div>
                  <div>
                    <h3 className="text-lg font-black text-slate-900 tracking-tight leading-snug">Income Account Credited!</h3>
                    <p className="text-xs text-slate-500 mt-1.5 max-w-xs leading-relaxed">
                      You have generated <span className="text-emerald-600 font-extrabold">${earnedDollar.toFixed(2)} USD</span> successfully. Check your Profile Earnings dashboard for detailed ledger balances.
                    </p>
                  </div>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setAdState('idle');
                    }}
                    className="w-full py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition cursor-pointer font-sans"
                  >
                    Back to Feed View
                  </button>
                </div>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
