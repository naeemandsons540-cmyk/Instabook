import React, { useState, useEffect, useRef } from 'react';
import { Message, UserProfile } from '../types';
import { collection, query, orderBy, onSnapshot, addDoc, doc, setDoc, updateDoc } from 'firebase/firestore';
import { db, auth, OperationType, handleFirestoreError } from '../firebase';
import { ChevronLeft, Send, User, MessageCircle, ShieldAlert } from 'lucide-react';
import { motion } from 'motion/react';

interface ChatViewProps {
  chatId: string;
  friendProfile: UserProfile | null;
  currentUserProfile: UserProfile | null;
  onBack: () => void;
}

export function ChatView({ chatId, friendProfile, currentUserProfile, onBack }: ChatViewProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [text, setText] = useState('');
  const [sending, setSending] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const currentUid = auth.currentUser?.uid;

  // 1. Listen to real-time chat messages
  useEffect(() => {
    const listPath = `chats/${chatId}/messages`;
    const messagesCol = collection(db, 'chats', chatId, 'messages');
    const q = query(messagesCol, orderBy('createdAt', 'asc'));

    const unsub = onSnapshot(q, (snapshot) => {
      const list: Message[] = [];
      snapshot.forEach((doc) => {
        list.push({ id: doc.id, ...doc.data() } as Message);
      });
      setMessages(list);
    }, (err) => {
      console.error(err);
      handleFirestoreError(err, OperationType.GET, listPath);
    });

    return () => unsub();
  }, [chatId]);

  // 2. Auto-scroll to latest message
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim() || sending) return;

    setSending(true);
    setErrorMsg(null);

    const user = auth.currentUser;
    if (!user || !currentUserProfile) {
      setErrorMsg('Session expired. Please log in.');
      setSending(false);
      return;
    }

    try {
      // Create message document with pre-generated document ID to comply with security rules
      const msCol = collection(db, 'chats', chatId, 'messages');
      const docRef = doc(msCol);

      const messagePayload = {
        id: docRef.id,
        chatId: chatId,
        senderId: user.uid,
        senderName: currentUserProfile.name,
        senderPhoto: currentUserProfile.photoURL,
        content: text.trim(),
        createdAt: new Date() // Translates to Firebase Timestamp
      };

      await setDoc(docRef, messagePayload);

      // Update parent Chat document meta for list preview sorting
      const chatRef = doc(db, 'chats', chatId);
      await updateDoc(chatRef, {
        lastMessage: text.trim(),
        lastMessageSenderId: user.uid,
        lastMessageTime: new Date()
      });

      setText('');
    } catch (err: any) {
      console.error(err);
      handleFirestoreError(err, OperationType.WRITE, `chats/${chatId}/messages`);
      setErrorMsg(err.message || 'Message failed to go through.');
    } finally {
      setSending(false);
    }
  };

  const formatTime = (ts: any) => {
    if (!ts) return '';
    const date = ts.toDate ? ts.toDate() : new Date(ts);
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col pb-16 font-sans select-none" id="chat_view_root">
      {/* Upper Direct Header */}
      <header className="sticky top-0 h-14 bg-white border-b border-slate-100 flex items-center px-3 justify-between z-10 shadow-sm" id="chat_header">
        <div className="flex items-center gap-2">
          <button id="direct_chat_back_btn" onClick={onBack} className="p-1.5 hover:bg-slate-100/80 active:bg-slate-200/50 rounded-full transition cursor-pointer">
            <ChevronLeft className="w-6 h-6 text-slate-700" />
          </button>
          
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-full overflow-hidden bg-slate-100 border border-slate-100">
              {friendProfile?.photoURL ? (
                <img src={friendProfile.photoURL} alt={friendProfile.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
              ) : (
                <User className="w-4.5 h-4.5 text-slate-400 m-auto mt-2" />
              )}
            </div>
            <div>
              <div className="font-bold text-slate-900 text-xs sm:text-xs.1 leading-snug">{friendProfile?.name || 'Loading friend...'}</div>
              <div className="text-[9px] text-emerald-600 font-bold tracking-tight">● Active Connection</div>
            </div>
          </div>
        </div>

        <MessageCircle className="w-5 h-5 text-blue-500 mr-2" />
      </header>

      {/* Message Stream Chronological Scrawl */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3.5 max-w-xl mx-auto w-full flex flex-col justify-end" id="message_scroller">
        {messages.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center text-center p-6 text-slate-400 space-y-2 mt-auto" id="no_messages_prompt">
            <MessageCircle className="w-10 h-10 stroke-[1.5] text-slate-300" />
            <h4 className="font-bold text-xs">Say Hello!</h4>
            <p className="text-[10.5px]">Begin messaging with your friend securely in real-time.</p>
          </div>
        ) : (
          <div className="space-y-3 mt-auto" id="messages_thread_box">
            {messages.map((message) => {
              const isOwn = message.senderId === currentUid;
              return (
                <div key={message.id} className={`flex ${isOwn ? 'justify-end' : 'justify-start'}`} id={`msg_wrap_${message.id}`}>
                  <div className={`flex gap-2 max-w-[80%] items-end ${isOwn ? 'flex-row-reverse' : 'flex-row'}`}>
                    {/* Tiny profile circle bubble on incoming messages */}
                    {!isOwn && (
                      <div className="w-6 h-6 rounded-full overflow-hidden bg-slate-200 border shrink-0">
                        <img src={message.senderPhoto || friendProfile?.photoURL || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&h=150'} alt="Sender" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                      </div>
                    )}
                    
                    <div className="flex flex-col">
                      <div
                        className={`px-4 py-2.5 rounded-2xl text-xs leading-normal select-text break-words ${
                          isOwn
                            ? 'bg-blue-600 text-white rounded-br-none shadow-sm font-semibold'
                            : 'bg-white text-slate-800 border border-slate-150 rounded-bl-none font-medium'
                        }`}
                      >
                        {message.content}
                      </div>
                      <span className={`text-[8.5px] text-slate-400 font-bold mt-1.2 px-1 ${isOwn ? 'text-right' : 'text-left'}`}>
                        {formatTime(message.createdAt)}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
            <div ref={messagesEndRef} />
          </div>
        )}
      </div>

      {/* Chat sending utility tray */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-150 p-3 flex flex-col z-35" id="chat_input_belt">
        <form onSubmit={handleSendMessage} className="flex items-center gap-2 max-w-xl mx-auto w-full">
          <input
            id="chat_message_input"
            type="text"
            placeholder="Type a message..."
            value={text}
            onChange={(e) => setText(e.target.value)}
            disabled={sending}
            autoComplete="off"
            className="flex-1 bg-slate-55 border border-slate-200 px-4 py-2.5 rounded-full text-xs text-slate-900 outline-none focus:border-blue-500 focus:bg-white transition"
          />
          <button
            id="chat_send_btn"
            type="submit"
            disabled={!text.trim() || sending}
            className="p-3 bg-blue-600 hover:bg-blue-700 disabled:opacity-45 transition text-white rounded-full flex items-center justify-center shrink-0 shadow-sm cursor-pointer"
          >
            {sending ? (
              <span className="w-4 h-4 block rounded-full border-2 border-white border-t-transparent animate-spin" />
            ) : (
              <Send className="w-4 h-4 fill-white" />
            )}
          </button>
        </form>

        {errorMsg && (
          <div className="mt-2 p-2 bg-rose-50 border border-rose-100 rounded-xl flex items-center gap-2 text-rose-700 text-[10px] max-w-xl mx-auto w-full" id="chat_error_message">
            <ShieldAlert className="w-3.5 h-3.5 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}
      </div>
    </div>
  );
}
