import { useEffect, useState } from 'react';
import { collection, query, orderBy, onSnapshot, doc, updateDoc, writeBatch, getDocs } from 'firebase/firestore';
import { db, auth, OperationType, handleFirestoreError } from '../firebase';
import { Notification } from '../types';
import { Bell, Heart, MessageSquare, UserPlus, UserCheck, CheckCircle2, AlertCircle } from 'lucide-react';
import { motion } from 'motion/react';

interface NotificationsViewProps {
  onSelectPost: (postId: string) => void;
  onSelectUser: (userId: string) => void;
  onUnreadCountChange?: (count: number) => void;
  blockedUserIds?: string[];
}

export function NotificationsView({
  onSelectPost,
  onSelectUser,
  onUnreadCountChange,
  blockedUserIds = [],
}: NotificationsViewProps) {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);
  const currentUid = auth.currentUser?.uid;

  // 1. Listen to user's notifications in real-time
  useEffect(() => {
    if (!currentUid) return;

    const notCol = collection(db, 'users', currentUid, 'notifications');
    const q = query(notCol, orderBy('createdAt', 'desc'));

    const unsub = onSnapshot(q, (snapshot) => {
      const list: Notification[] = [];
      let unreadCount = 0;

      snapshot.forEach((doc) => {
        const item = { id: doc.id, ...doc.data() } as Notification;
        list.push(item);
        if (!item.isRead) unreadCount++;
      });

      setNotifications(list);
      setLoading(false);

      if (onUnreadCountChange) {
        onUnreadCountChange(unreadCount);
      }
    }, (err) => {
      console.error(err);
      handleFirestoreError(err, OperationType.GET, `users/${currentUid}/notifications`);
    });

    return () => unsub();
  }, [currentUid]);

  const handleNotificationTap = async (item: Notification) => {
    if (!currentUid) return;
    
    // 1. Mark as read in Firestore
    try {
      const docRef = doc(db, 'users', currentUid, 'notifications', item.id);
      await updateDoc(docRef, { isRead: true });
    } catch (err) {
      console.error('Failed to mark notification as read:', err);
    }

    // 2. Route accordingly
    if ((item.type === 'like' || item.type === 'comment') && item.postId) {
      onSelectPost(item.postId);
    } else {
      onSelectUser(item.actorId);
    }
  };

  const markAllRead = async () => {
    if (!currentUid || notifications.length === 0) return;
    try {
      const batch = writeBatch(db);
      const unreads = notifications.filter(n => !n.isRead);
      
      unreads.forEach(n => {
        const ref = doc(db, 'users', currentUid, 'notifications', n.id);
        batch.update(ref, { isRead: true });
      });

      await batch.commit();
    } catch (err) {
      console.error('Failed to mark all read:', err);
    }
  };

  // Convert Firebase date formats
  const formatTime = (ts: any) => {
    if (!ts) return '';
    const date = ts.toDate ? ts.toDate() : new Date(ts);
    return date.toLocaleDateString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
  };

  const getIcon = (type: string) => {
    switch (type) {
      case 'like':
        return <Heart className="w-4.5 h-4.5 text-rose-500 fill-rose-500" />;
      case 'comment':
        return <MessageSquare className="w-4.5 h-4.5 text-blue-500 fill-blue-50" />;
      case 'friend_request':
        return <UserPlus className="w-4.5 h-4.5 text-orange-500" />;
      case 'friend_accept':
        return <UserCheck className="w-4.5 h-4.5 text-emerald-500" />;
      default:
        return <Bell className="w-4.5 h-4.5 text-slate-400" />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 pb-20 font-sans select-none" id="notifications_view_root">
      {/* Top Header navbar specifications */}
      <header className="sticky top-0 bg-white border-b border-slate-100 px-4 h-14 flex items-center justify-between z-30 shadow-sm" id="notifications_header">
        <h1 className="font-extrabold text-slate-900 text-base sm:text-base.1">Activity Alerts</h1>
        {notifications.some(n => !n.isRead) && (
          <button
            id="mark_all_read_btn"
            onClick={markAllRead}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-full text-xs font-bold transition cursor-pointer"
          >
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Mark read</span>
          </button>
        )}
      </header>

      {/* Primary Notifications Grid */}
      <main className="max-w-md lg:max-w-2xl mx-auto p-4" id="notifications_scroller_body">
        {loading ? (
          <div className="flex flex-col items-center justify-center py-24 text-slate-400 gap-2" id="notif_loading_spinner">
            <span className="w-6 h-6 block rounded-full border-3 border-blue-500 border-t-transparent animate-spin"></span>
            <span className="text-[11px] font-semibold text-slate-450">Loading notifications...</span>
          </div>
        ) : notifications.length === 0 ? (
          <div className="text-center py-20 bg-white rounded-2xl border border-slate-100 p-8 cursor-default" id="notif_blank_prompt">
            <Bell className="w-12 h-12 text-slate-200 mx-auto mb-4 stroke-[1.2]" />
            <h3 className="font-bold text-sm text-slate-700">All quiet for now</h3>
            <p className="text-slate-400 text-xs mt-1 leading-snug">When people like or comment on your posts, or send connections requests, they’ll show up here.</p>
          </div>
        ) : (
          <div className="space-y-2" id="notification_cards_list">
            {notifications
              .filter((item) => !blockedUserIds.includes(item.actorId))
              .map((item) => (
              <div
                key={item.id}
                id={`notif_row_${item.id}`}
                onClick={() => handleNotificationTap(item)}
                className={`p-3 bg-white rounded-2xl border transition hover:bg-slate-50 relative flex items-start gap-3 cursor-pointer ${
                  item.isRead ? 'border-slate-100' : 'border-blue-100 shadow-sm'
                }`}
              >
                {/* Unread dynamic dot marker */}
                {!item.isRead && (
                  <span className="absolute top-4 right-4 w-2 h-2 rounded-full bg-blue-600 animate-pulse" />
                )}

                {/* Actor Profile icon */}
                <div className="relative shrink-0 select-none">
                  <div className="w-10 h-10 rounded-full overflow-hidden bg-slate-50 border border-slate-100">
                    <img src={item.actorPhotoURL || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&h=150'} alt="Actor" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                  </div>
                  {/* Small Action overlay bubble index icon */}
                  <span className="absolute -bottom-1 -right-1 p-1 bg-white rounded-full shadow-md border border-slate-50">
                    {getIcon(item.type)}
                  </span>
                </div>

                {/* Notification body details description */}
                <div className="flex-1 min-w-0 pr-2">
                  <p className="text-xs text-slate-800 leading-relaxed font-bold">
                    {item.actorName}{' '}
                    <span className="font-medium text-slate-500 text-xs.1">{item.text}</span>
                  </p>
                  <span className="text-[9.5px] text-slate-400 mt-1.5 block font-semibold">{formatTime(item.createdAt)}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
