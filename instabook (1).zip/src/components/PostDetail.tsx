import React, { useState, useEffect, useRef } from 'react';
import { Post, Comment, UserProfile } from '../types';
import { collection, query, orderBy, onSnapshot, addDoc, doc, setDoc, getDoc, updateDoc, increment, getDocs, where, deleteDoc } from 'firebase/firestore';
import { db, auth, OperationType, handleFirestoreError } from '../firebase';
import { ChevronLeft, Send, ThumbsUp, MessageSquare, Share2, CornerDownRight, ShieldAlert } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface PostDetailProps {
  postId: string;
  currentUserProfile: UserProfile | null;
  onBack: () => void;
  onSelectUser: (userId: string) => void;
}

export function PostDetail({ postId, currentUserProfile, onBack, onSelectUser }: PostDetailProps) {
  const [post, setPost] = useState<Post | null>(null);
  const [comments, setComments] = useState<Comment[]>([]);
  const [commentText, setCommentText] = useState('');
  const [isLiked, setIsLiked] = useState(false);
  const [likesCount, setLikesCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [submittingComment, setSubmittingComment] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [shareToast, setShareToast] = useState(false);

  const commentsEndRef = useRef<HTMLDivElement>(null);
  const currentUid = auth.currentUser?.uid;

  // 1. Fetch Post Specs in real-time or getDoc
  useEffect(() => {
    const postRef = doc(db, 'posts', postId);
    const unsub = onSnapshot(postRef, (snapshot) => {
      if (snapshot.exists()) {
        const data = snapshot.data();
        setPost({ id: snapshot.id, ...data } as Post);
        setLikesCount(data.likesCount || 0);
      } else {
        setPost(null);
      }
      setLoading(false);
    }, (err) => {
      console.error(err);
      handleFirestoreError(err, OperationType.GET, `posts/${postId}`);
    });

    return () => unsub();
  }, [postId]);

  // 2. Fetch Comments Subcollection in real-time
  useEffect(() => {
    const commentsCol = collection(db, 'posts', postId, 'comments');
    const q = query(commentsCol, orderBy('createdAt', 'asc'));

    const unsub = onSnapshot(q, (snapshot) => {
      const list: Comment[] = [];
      snapshot.forEach((doc) => {
        list.push({ id: doc.id, ...doc.data() } as Comment);
      });
      setComments(list);
      
      // Mark notifications about this post read
      markPostNotificationsRead();
    }, (err) => {
      console.error(err);
      handleFirestoreError(err, OperationType.GET, `posts/${postId}/comments`);
    });

    return () => unsub();
  }, [postId]);

  // 3. Check Liked State
  useEffect(() => {
    if (!currentUid) return;
    const fetchLikeStatus = async () => {
      try {
        const likeRef = doc(db, 'posts', postId, 'likes', currentUid);
        const snapshot = await getDocs(query(collection(db, 'posts', postId, 'likes'), where('__name__', '==', currentUid)));
        setIsLiked(!snapshot.empty);
      } catch (err) {
        console.error(err);
      }
    };
    fetchLikeStatus();
  }, [postId, currentUid]);

  // Scroll downwards when new comments are listed
  useEffect(() => {
    commentsEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [comments]);

  const markPostNotificationsRead = async () => {
    if (!currentUid) return;
    try {
      const notCol = collection(db, 'users', currentUid, 'notifications');
      const q = query(notCol, where('postId', '==', postId), where('isRead', '==', false));
      const res = await getDocs(q);
      res.forEach(async (nDoc) => {
        await updateDoc(doc(db, 'users', currentUid, 'notifications', nDoc.id), {
          isRead: true
        });
      });
    } catch (err) {
      console.error('Failed reading notifications', err);
    }
  };

  const handleLikeToggle = async () => {
    if (!currentUid || !post) return;

    const previousLiked = isLiked;
    const previousCount = likesCount;

    setIsLiked(!previousLiked);
    setLikesCount(previousCount + (previousLiked ? -1 : 1));

    const postRef = doc(db, 'posts', postId);
    const likeRef = doc(db, 'posts', postId, 'likes', currentUid);

    try {
      if (previousLiked) {
        await deleteDoc(likeRef);
        await updateDoc(postRef, { likesCount: increment(-1) });
      } else {
        await setDoc(likeRef, { uid: currentUid, timestamp: new Date() });
        await updateDoc(postRef, { likesCount: increment(1) });

        // Notification setup
        if (post.authorId !== currentUid) {
          let actorName = currentUserProfile?.name || auth.currentUser?.displayName || 'Someone';
          let actorPhotoURL = currentUserProfile?.photoURL || auth.currentUser?.photoURL || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&h=150';

          if (!currentUserProfile) {
            try {
              const userDoc = await getDoc(doc(db, 'users', currentUid));
              if (userDoc.exists()) {
                const uData = userDoc.data();
                if (uData.name) actorName = uData.name;
                if (uData.photoURL) actorPhotoURL = uData.photoURL;
              }
            } catch (profileErr) {
              console.error('Failed to load like actor custom profile details in detail view:', profileErr);
            }
          }

          const notificationId = `${currentUid}_like_${post.id}`;
          const notRef = doc(db, 'users', post.authorId, 'notifications', notificationId);
          await setDoc(notRef, {
            id: notificationId,
            actorId: currentUid,
            actorName: actorName,
            actorPhotoURL: actorPhotoURL,
            type: 'like',
            postId: post.id,
            text: 'liked your post',
            isRead: false,
            createdAt: new Date()
          });
        }
      }
    } catch (err: any) {
      setIsLiked(previousLiked);
      setLikesCount(previousCount);
      console.error(err);
    }
  };

  const handleSendComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentText.trim() || submittingComment || !post) return;

    setSubmittingComment(true);
    setErrorMsg(null);

    const user = auth.currentUser;
    if (!user || !currentUserProfile) {
      setErrorMsg('You must be logged in to reply/comment.');
      setSubmittingComment(false);
      return;
    }

    try {
      // Add to subcollection with pre-generated document ID to comply with security rules
      const cmCol = collection(db, 'posts', postId, 'comments');
      const docRef = doc(cmCol);

      const commentPayload = {
        id: docRef.id,
        postId: postId,
        authorId: user.uid,
        authorName: currentUserProfile.name,
        authorPhotoURL: currentUserProfile.photoURL,
        authorUsername: currentUserProfile.username,
        content: commentText.trim(),
        createdAt: new Date()
      };

      await setDoc(docRef, commentPayload);

      // Update parent post commentsCount ATOMICALLY
      const prRef = doc(db, 'posts', postId);
      await updateDoc(prRef, { commentsCount: increment(1) });

      // Send Notification to author
      if (post.authorId !== user.uid) {
        const notId = `${user.uid}_comment_${docRef.id}`;
        const targetNotRef = doc(db, 'users', post.authorId, 'notifications', notId);
        await setDoc(targetNotRef, {
          id: notId,
          actorId: user.uid,
          actorName: currentUserProfile.name,
          actorPhotoURL: currentUserProfile.photoURL,
          type: 'comment',
          postId: post.id,
          text: `commented: "${commentText.substring(0, 30)}${commentText.length > 30 ? '...' : ''}"`,
          isRead: false,
          createdAt: new Date()
        });
      }

      setCommentText('');
    } catch (err: any) {
      console.error(err);
      handleFirestoreError(err, OperationType.WRITE, `posts/${postId}/comments`);
      setErrorMsg(err.message || 'Comment failed to register.');
    } finally {
      setSubmittingComment(false);
    }
  };

  const handleShareClick = () => {
    const appUrl = window.location.origin;
    const shareLink = `${appUrl}?post=${postId}`;
    navigator.clipboard.writeText(shareLink).then(() => {
      setShareToast(true);
      setTimeout(() => setShareToast(false), 2200);
    });
  };

  const getEmbedVideoSrc = (rawUrl: string) => {
    if (!rawUrl) return '';
    if (rawUrl.includes('youtube.com') || rawUrl.includes('youtu.be')) {
      const reg = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/;
      const m = rawUrl.match(reg);
      if (m && m[2].length === 11) return `https://www.youtube.com/embed/${m[2]}`;
    }
    if (rawUrl.includes('drive.google.com')) {
      return rawUrl.replace('/view', '/preview').replace('/edit', '/preview');
    }
    return rawUrl;
  };

  const formatTime = (ts: any) => {
    if (!ts) return '';
    const date = ts.toDate ? ts.toDate() : new Date(ts);
    return date.toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-4" id="post_detail_loading">
        <span className="w-8 h-8 rounded-full border-4 border-blue-500 border-t-transparent animate-spin"></span>
        <span className="text-slate-400 text-xs font-bold mt-3">Loading Post Details...</span>
      </div>
    );
  }

  if (!post) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-6 text-center select-none" id="post_detail_not_found">
        <div className="text-slate-400 text-sm font-bold">Post not found or has been deleted.</div>
        <button id="not_found_back_btn" onClick={onBack} className="mt-4 px-4 py-2 bg-slate-200 text-slate-800 rounded-xl font-bold text-xs hover:bg-slate-300 transition cursor-pointer">
          Go Back Feed
        </button>
      </div>
    );
  }

  const isSponsored = post.authorUsername.toLowerCase() === 'adsterra official' || post.id.startsWith('ad_');

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col pb-16 font-sans select-none" id="post_detail_root">
      {/* Upper Navigation Back Header */}
      <header className="sticky top-0 h-14 bg-white border-b border-slate-100 flex items-center px-4 justify-between z-10 shadow-sm" id="detail_header">
        <div className="flex items-center gap-2">
          <button id="post_detail_back_arrow" onClick={onBack} className="p-1.5 hover:bg-slate-100/80 active:bg-slate-200/50 rounded-full transition cursor-pointer">
            <ChevronLeft className="w-6 h-6 text-slate-700" />
          </button>
          <span className="font-extrabold text-slate-900 text-base">Thread</span>
        </div>
        <span className="text-[11px] font-bold text-slate-400 uppercase tracking-widest bg-slate-50 px-2.5 py-0.5 rounded-full border border-slate-100">Instabook</span>
      </header>

      {/* Main Scratched view scroll block */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 max-w-xl mx-auto w-full">
        {/* Main Post Section content */}
        <div className="bg-white rounded-2xl border border-slate-150 p-4 space-y-3 shadow-inner">
          {/* Header Author Info */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div
                onClick={() => { if (!isSponsored) onSelectUser(post.authorId); }}
                className="w-10 h-10 rounded-full overflow-hidden bg-slate-100 shrink-0 border cursor-pointer"
              >
                <img src={post.authorPhotoURL || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&h=150'} alt={post.authorName} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
              </div>
              <div>
                <div className="flex items-center gap-1.5 leading-tight">
                  <span
                    onClick={() => { if (!isSponsored) onSelectUser(post.authorId); }}
                    className="font-bold text-slate-900 text-sm hover:underline cursor-pointer"
                  >
                    {post.authorName}
                  </span>
                  {isSponsored && (
                    <span className="bg-amber-100 text-amber-800 text-[10px] font-bold px-1.5 py-0.5 rounded-full">Sponsored</span>
                  )}
                </div>
                <div className="text-[11px] text-slate-400 mt-1 font-medium">@{post.authorUsername} • {formatTime(post.createdAt)}</div>
              </div>
            </div>
          </div>

          {/* Post content body text */}
          {post.content && (
            <p className="text-slate-800 text-sm leading-relaxed whitespace-pre-wrap break-words">{post.content}</p>
          )}

          {/* Post Image */}
          {post.imageURL && (
            <div className="w-full max-h-96 rounded-xl overflow-hidden bg-slate-50 border border-slate-150">
              <img src={post.imageURL} alt="Post content" className="w-full h-full object-contain" referrerPolicy="no-referrer" />
            </div>
          )}

          {/* Post Video */}
          {post.videoURL && (
            <div className="w-full h-56 rounded-xl overflow-hidden bg-black border border-slate-150">
              <iframe
                src={getEmbedVideoSrc(post.videoURL)}
                title="Google Drive / Youtube player"
                className="w-full h-full"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              />
            </div>
          )}

          {/* Divider with Stats like details */}
          <div className="flex items-center justify-between border-t border-slate-100 pt-3 text-xs text-slate-400 px-1 font-bold">
            <span>{likesCount} Likes</span>
            <span>{comments.length} Comments</span>
          </div>

          {/* Action Row buttons */}
          <div className="grid grid-cols-3 border-t border-slate-100 pt-1 mt-1">
            <button
              onClick={handleLikeToggle}
              className={`py-2 text-xs font-bold rounded-xl flex items-center justify-center gap-2 transition hover:bg-slate-50 cursor-pointer ${
                isLiked ? 'text-blue-600 scale-102 font-extrabold' : 'text-slate-600'
              }`}
              id="detail_like_toggle"
            >
              <ThumbsUp className={`w-4 h-4 ${isLiked ? 'fill-blue-600 stroke-blue-600' : ''}`} />
              <span>Like</span>
            </button>

            <div className="py-2 text-xs font-semibold text-slate-400 flex items-center justify-center gap-2">
              <MessageSquare className="w-4 h-4 text-slate-350" />
              <span>Comment</span>
            </div>

            <button
              onClick={handleShareClick}
              className="py-2 text-xs font-bold text-slate-600 rounded-xl flex items-center justify-center gap-2 transition hover:bg-slate-50 relative cursor-pointer"
              id="detail_share_btn"
            >
              <Share2 className="w-4 h-4" />
              <span>Share</span>

              <AnimatePresence>
                {shareToast && (
                  <motion.span
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.9 }}
                    className="absolute bottom-full mb-1 bg-slate-900 text-white text-[9.5px] py-1 px-2.5 rounded-full font-normal"
                  >
                    Link copied!
                  </motion.span>
                )}
              </AnimatePresence>
            </button>
          </div>
        </div>

        {/* Comments Section Title with listings */}
        <div className="space-y-3" id="discussion_container">
          <h3 className="text-slate-800 text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 px-1">
            <CornerDownRight className="w-4 h-4 text-slate-400" />
            <span>Discussion ({comments.length})</span>
          </h3>

          {comments.length === 0 ? (
            <div className="bg-white rounded-2xl border border-slate-100 p-6 text-center text-xs text-slate-400" id="no_comments_prompt">
              Be the first to comment on this post. Write below!
            </div>
          ) : (
            <div className="space-y-2.5" id="comments_list">
              {comments.map((comment) => (
                <div key={comment.id} className="flex gap-3 bg-white p-3 rounded-2xl border border-slate-100" id={`comment_box_${comment.id}`}>
                  <div
                    onClick={() => onSelectUser(comment.authorId)}
                    className="w-8 h-8 rounded-full overflow-hidden bg-slate-50 border cursor-pointer shrink-0"
                  >
                    <img src={comment.authorPhotoURL || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&h=150'} alt={comment.authorName} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                  </div>
                  <div className="flex-1 space-y-1">
                    <div className="flex items-center justify-between">
                      <span
                        onClick={() => onSelectUser(comment.authorId)}
                        className="font-bold text-slate-900 text-xs hover:underline cursor-pointer"
                      >
                        {comment.authorName}
                      </span>
                      <span className="text-[9px] text-slate-400 font-semibold">{formatTime(comment.createdAt)}</span>
                    </div>
                    <p className="text-slate-700 text-xs leading-relaxed whitespace-pre-wrap break-words">{comment.content}</p>
                  </div>
                </div>
              ))}
              <div ref={commentsEndRef} />
            </div>
          )}
        </div>
      </div>

      {/* Sticky Comment input box at bottom */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-150 p-3 flex flex-col z-30" id="comment_input_tray">
        <form onSubmit={handleSendComment} className="flex items-center gap-2 max-w-xl mx-auto w-full">
          <input
            id="comment_text_input"
            type="text"
            placeholder="Write a comment..."
            value={commentText}
            onChange={(e) => setCommentText(e.target.value)}
            disabled={submittingComment}
            className="flex-1 bg-slate-55 border border-slate-200 px-4 py-2.5 rounded-full text-xs text-slate-900 outline-none focus:border-blue-500 focus:bg-white transition"
          />
          <button
            id="send_comment_btn"
            type="submit"
            disabled={!commentText.trim() || submittingComment}
            className="p-3 bg-blue-600 hover:bg-blue-700 disabled:opacity-40 transition text-white rounded-full flex items-center justify-center shrink-0 shadow-sm cursor-pointer"
          >
            {submittingComment ? (
              <span className="w-4 h-4 block rounded-full border-2 border-white border-t-transparent animate-spin"></span>
            ) : (
              <Send className="w-4 h-4 fill-white" />
            )}
          </button>
        </form>

        {errorMsg && (
          <div className="mt-2 p-2 bg-rose-50 border border-rose-100 rounded-xl flex items-center gap-2 text-rose-700 text-[10px] max-w-xl mx-auto w-full" id="detail_error_message">
            <ShieldAlert className="w-3.5 h-3.5 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}
      </div>
    </div>
  );
}
