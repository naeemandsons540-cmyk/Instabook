/**
 * Utility to compress images to reasonable sizes and upload them to ImgBB
 * or fallback to highly efficient compressed base64 strings if ImgBB fails/is unconfigured.
 */

export async function compressImage(file: File, maxW = 600, maxH = 600, quality = 0.7): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = (event) => {
      const img = new Image();
      img.src = event.target?.result as string;
      img.onload = () => {
        const canvas = document.createElement('canvas');
        let width = img.width;
        let height = img.height;

        // Calculate aspect ratio resizing
        if (width > height) {
          if (width > maxW) {
            height = Math.round((height * maxW) / width);
            width = maxW;
          }
        } else {
          if (height > maxH) {
            width = Math.round((width * maxH) / height);
            height = maxH;
          }
        }

        canvas.width = width;
        canvas.height = height;

        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(event.target?.result as string); // Fallback to raw Base64
          return;
        }

        ctx.drawImage(img, 0, 0, width, height);
        // Output compressed jpeg format
        const dataUrl = canvas.toDataURL('image/jpeg', quality);
        resolve(dataUrl);
      };
      img.onerror = (err) => reject(err);
    };
    reader.onerror = (err) => reject(err);
  });
}

export async function uploadImage(file: File): Promise<string> {
  try {
    // 1. Compress first to reduce upload bandwidth and limit base64 payload size
    const compressedBase64 = await compressImage(file, 600, 600, 0.7);

    // 2. Fetch the ImgBB key
    const imgbbKey = (import.meta as any).env?.VITE_IMGBB_API_KEY;
    if (!imgbbKey) {
      console.warn("No VITE_IMGBB_API_KEY environment variable found. Falling back to local Base64 storage.");
      return compressedBase64;
    }

    // Prepare ImgBB format. ImgBB accepts a base64 string stripped of the header "data:image/jpeg;base64,"
    const strippedBase64 = compressedBase64.replace(/^data:image\/\w+;base64,/, "");
    const formData = new FormData();
    formData.append('image', strippedBase64);

    const apiRef = `https://api.imgbb.com/1/upload?key=${imgbbKey}`;
    const response = await fetch(apiRef, {
      method: 'POST',
      body: formData,
    });

    if (!response.ok) {
      throw new Error(`ImgBB API responded with ${response.status}`);
    }

    const json = await response.json();
    if (json && json.data && json.data.url) {
      return json.data.url;
    }

    throw new Error('Invalid ImgBB API response structure');
  } catch (error) {
    console.error('Failed to upload image to ImgBB:', error);
    // Graceful fallback: return the compressed local Base64 URL so the app remains fully functional
    const fallbackBase64 = await compressImage(file, 400, 400, 0.6);
    return fallbackBase64;
  }
}
