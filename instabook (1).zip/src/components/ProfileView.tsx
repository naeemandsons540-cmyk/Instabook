import React, { useState, useEffect } from 'react';
import { collection, query, orderBy, onSnapshot, doc, getDoc, getDocs, updateDoc, setDoc, query as fsQuery, where, deleteDoc, increment } from 'firebase/firestore';
import { signOut } from 'firebase/auth';
import { db, auth, OperationType, handleFirestoreError } from '../firebase';
import { Post, Story, UserProfile, FriendRequest } from '../types';
import { User, Image, Video, FileText, Edit, CheckCircle, Sliders, Calendar, Camera, Info, UserPlus, UserCheck, Users, UserMinus, LogOut, CheckCircle2, ShieldAlert } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { uploadImage } from '../utils/image';

interface ProfileViewProps {
  userId: string | null; // null for current authenticated user
  currentUserProfile: UserProfile | null;
  onSelectPost: (postId: string) => void;
  onSelectUser: (userId: string) => void;
  onStartChat: (friendId: string) => void; // Trigger direct chat routing
  onProfileUpdated: () => void;
  blockedUserIds: string[];
  myBlockedUsers: any[];
}

export function ProfileView({
  userId,
  currentUserProfile,
  onSelectPost,
  onSelectUser,
  onStartChat,
  onProfileUpdated,
  blockedUserIds = [],
  myBlockedUsers = [],
}: ProfileViewProps) {
  const currentUid = auth.currentUser?.uid;
  const isOwnProfile = !userId || userId === currentUid;
  const targetUid = userId || currentUid;

  // Profiles states
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [posts, setPosts] = useState<Post[]>([]);
  const [stories, setStories] = useState<Story[]>([]);
  const [activeTab, setActiveTab] = useState<'posts' | 'stories' | 'videos' | 'friends' | 'blocked' | 'earnings'>('posts');
  const [loading, setLoading] = useState(true);

  // Financial payout states
  const [payoutList, setPayoutList] = useState<any[]>([]);
  const [payoutLoading, setPayoutLoading] = useState(false);
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'easypaisa' | 'jazzcash' | 'binance' | 'bank'>('easypaisa');
  const [accountNumber, setAccountNumber] = useState('');
  const [accountTitle, setAccountTitle] = useState('');
  const [payoutStatus, setPayoutStatus] = useState<string | null>(null);

  // Friendship states
  const [friendRequest, setFriendRequest] = useState<FriendRequest | null>(null);
  const [isFriend, setIsFriend] = useState(false);
  const [friendsList, setFriendsList] = useState<any[]>([]);
  const [loadingFriends, setLoadingFriends] = useState(false);

  // Profile Edit states
  const [isEditing, setIsEditing] = useState(false);
  const [editName, setEditName] = useState('');
  const [editUsername, setEditUsername] = useState('');
  const [editDob, setEditDob] = useState('');
  const [editGender, setEditGender] = useState('');
  const [newAvatarFile, setNewAvatarFile] = useState<File | null>(null);
  const [editAvatarPreview, setEditAvatarPreview] = useState('');
  const [usernameStatus, setUsernameStatus] = useState<'available' | 'taken' | 'reserved' | null>(null);
  const [checkingUsername, setCheckingUsername] = useState(false);
  const [updatingProfile, setUpdatingProfile] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // 1. Fetch Target Profile
  useEffect(() => {
    if (!targetUid) return;
    setLoading(true);

    const unsub = onSnapshot(doc(db, 'users', targetUid), (docSnap) => {
      if (docSnap.exists()) {
        const val = docSnap.data() as UserProfile;
        setProfile(val);
        // Pre-fill edits
        setEditName(val.name);
        setEditUsername(val.username);
        setEditDob(val.dob);
        setEditGender(val.gender);
        setEditAvatarPreview(val.photoURL);
      }
      setLoading(false);
    }, (err) => {
      console.error(err);
      handleFirestoreError(err, OperationType.GET, `users/${targetUid}`);
    });

    return () => unsub();
  }, [targetUid]);

  // 2. Fetch Target Posts & Stories
  useEffect(() => {
    if (!targetUid) return;

    // Listen normal posts
    const qPosts = query(collection(db, 'posts'), where('authorId', '==', targetUid));
    const unsubPosts = onSnapshot(qPosts, (snap) => {
      const list: Post[] = [];
      snap.forEach(d => list.push({ id: d.id, ...d.data() } as Post));
      // Sort client-side by date desc
      list.sort((a, b) => {
        const da = a.createdAt?.toDate ? a.createdAt.toDate() : new Date(a.createdAt);
        const db = b.createdAt?.toDate ? b.createdAt.toDate() : new Date(b.createdAt);
        return db.getTime() - da.getTime();
      });
      setPosts(list);
    });

    // Listen Stories
    const qStories = query(collection(db, 'stories'), where('authorId', '==', targetUid));
    const unsubStories = onSnapshot(qStories, (snap) => {
      const list: Story[] = [];
      snap.forEach(d => {
        const s = d.data() as Story;
        // Keep active stories within 24h limits
        const sTime = s.createdAt?.toDate ? s.createdAt.toDate() : new Date(s.createdAt);
        const ageHours = (Date.now() - sTime.getTime()) / (1000 * 60 * 60);
        if (ageHours < 24) {
          list.push({ id: d.id, ...s } as Story);
        }
      });
      setStories(list);
    });

    return () => {
      unsubPosts();
      unsubStories();
    };
  }, [targetUid]);

  // 3. Track Friendship Handshake if viewing foreign profiles (fully real-time via sub onSnapshot)
  useEffect(() => {
    if (isOwnProfile || !currentUid || !targetUid) {
      setFriendRequest(null);
      setIsFriend(false);
      return;
    }

    let req1: FriendRequest | null = null;
    let req2: FriendRequest | null = null;

    const updateStates = () => {
      const activeReq = req1 || req2;
      setFriendRequest(activeReq);
      setIsFriend(activeReq?.status === 'accepted');
    };

    const unsub1 = onSnapshot(
      query(collection(db, 'friendRequests'), where('senderId', '==', currentUid), where('receiverId', '==', targetUid)),
      (snap) => {
        req1 = null;
        snap.forEach(d => { req1 = { id: d.id, ...d.data() } as FriendRequest; });
        updateStates();
      },
      (err) => console.error('Error fetching sent request status:', err)
    );

    const unsub2 = onSnapshot(
      query(collection(db, 'friendRequests'), where('senderId', '==', targetUid), where('receiverId', '==', currentUid)),
      (snap) => {
        req2 = null;
        snap.forEach(d => { req2 = { id: d.id, ...d.data() } as FriendRequest; });
        updateStates();
      },
      (err) => console.error('Error fetching received request status:', err)
    );

    return () => {
      unsub1();
      unsub2();
    };
  }, [isOwnProfile, currentUid, targetUid]);

  // 4. Real-time Subscription to this profile's friends list
  useEffect(() => {
    if (!targetUid) return;

    setLoadingFriends(true);
    const friendsCol = collection(db, 'users', targetUid, 'friends');
    const unsub = onSnapshot(friendsCol, (snapshot) => {
      const list: any[] = [];
      snapshot.forEach((docSnap) => {
        list.push({ id: docSnap.id, ...docSnap.data() });
      });
      setFriendsList(list);
      setLoadingFriends(false);
    }, (err) => {
      console.error('Error fetching friends list:', err);
      setLoadingFriends(false);
    });

    return () => unsub();
  }, [targetUid]);

  // 4b. Real-time Subscription to current user's payouts
  useEffect(() => {
    if (!isOwnProfile || !currentUid) return;
    const q = query(
      collection(db, 'withdrawals'),
      where('userId', '==', currentUid)
    );
    const unsub = onSnapshot(q, (snap) => {
      const list: any[] = [];
      snap.forEach((doc) => {
        list.push({ id: doc.id, ...doc.data() });
      });
      list.sort((a,b) => {
        const da = a.createdAt?.toDate ? a.createdAt.toDate() : new Date(a.createdAt || 0);
        const db = b.createdAt?.toDate ? b.createdAt.toDate() : new Date(b.createdAt || 0);
        return db.getTime() - da.getTime();
      });
      setPayoutList(list);
    });
    return () => unsub();
  }, [currentUid, isOwnProfile]);

  const handleRequestPayout = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUid || !profile) return;
    setPayoutStatus(null);
    setPayoutLoading(true);

    const amt = parseFloat(withdrawAmount);
    if (isNaN(amt) || amt <= 0) {
      setPayoutStatus('Please enter a valid amount.');
      setPayoutLoading(false);
      return;
    }

    const available = profile.adEarnings || 0;
    if (amt > available) {
      setPayoutStatus(`Insufficient earning balance. Your active reward is only $${available.toFixed(2)} USD.`);
      setPayoutLoading(false);
      return;
    }

    if (amt < 5) {
      setPayoutStatus('Minimum payout withdraw limit is $5.00 USD.');
      setPayoutLoading(false);
      return;
    }

    if (!accountNumber.trim() || !accountTitle.trim()) {
      setPayoutStatus('Please fill in both Account Number and Title Details.');
      setPayoutLoading(false);
      return;
    }

    try {
      const pcol = collection(db, 'withdrawals');
      const payoutId = `payout_${Date.now()}`;
      
      await setDoc(doc(pcol, payoutId), {
        id: payoutId,
        userId: currentUid,
        userName: profile.name,
        userUsername: profile.username,
        amount: amt,
        paymentMethod,
        accountNumber: accountNumber.trim(),
        accountTitle: accountTitle.trim(),
        status: 'pending',
        createdAt: new Date()
      });

      const userRef = doc(db, 'users', currentUid);
      const remainingAmount = Number((available - amt).toFixed(4));
      await updateDoc(userRef, {
        adEarnings: remainingAmount
      });

      setPayoutStatus('withdrawal_success');
      setWithdrawAmount('');
      setAccountNumber('');
      setAccountTitle('');
    } catch (err: any) {
      console.error(err);
      setPayoutStatus(err.message || 'Withdrawal submission failed.');
    } finally {
      setPayoutLoading(false);
    }
  };

  // Handle Edit Input Change with Validation
  const handleUsernameVerification = (val: string) => {
    const cleaned = val.replace(/\s+/g, '').replace(/[^a-zA-Z0-9_.]/g, '');
    setEditUsername(cleaned);

    const norm = cleaned.toLowerCase().trim();
    if (norm === 'adsterra official' || norm.includes('adsterra')) {
      setUsernameStatus('reserved');
      return;
    }
    if (cleaned === profile?.username) {
      setUsernameStatus('available');
      return;
    }
    if (cleaned.length < 3) {
      setUsernameStatus(null);
      return;
    }

    setCheckingUsername(true);
    const checkUnique = setTimeout(async () => {
      try {
        const q = query(collection(db, 'users'), where('username', '==', cleaned));
        const res = await getDocs(q);
        const matchOther = res.docs.filter(d => d.id !== currentUid);
        if (matchOther.length > 0) {
          setUsernameStatus('taken');
        } else {
          setUsernameStatus('available');
        }
      } catch (err) {
        console.error(err);
      } finally {
        setCheckingUsername(false);
      }
    }, 400);

    return () => clearTimeout(checkUnique);
  };

  const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (!file.type.startsWith('image/')) {
        setErrorMsg('Invalid image file content type.');
        return;
      }
      setNewAvatarFile(file);
      setEditAvatarPreview(URL.createObjectURL(file));
    }
  };

  const handleSaveProfileChanges = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editName.trim()) {
      setErrorMsg('Display Name is required.');
      return;
    }
    if (editUsername.length < 3) {
      setErrorMsg('Username must be at least 3 characters.');
      return;
    }
    if (usernameStatus === 'taken') {
      setErrorMsg('Username taken.');
      return;
    }
    if (usernameStatus === 'reserved') {
      setErrorMsg('Reserved username "Adsterra Official" cannot be selected.');
      return;
    }

    setUpdatingProfile(true);
    setErrorMsg(null);

    try {
      let finalPhotoUrl = profile?.photoURL || '';

      if (newAvatarFile) {
        finalPhotoUrl = await uploadImage(newAvatarFile);
      }

      const userRef = doc(db, 'users', currentUid!);
      await updateDoc(userRef, {
        name: editName.trim(),
        username: editUsername.toLowerCase().trim(),
        photoURL: finalPhotoUrl,
        dob: editDob,
        gender: editGender
      });

      setIsEditing(false);
      onProfileUpdated();
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || 'Profile updates failed.');
    } finally {
      setUpdatingProfile(false);
    }
  };

  // Friend Request Action Triggers
  const handleSendFriendRequest = async () => {
    if (!currentUid || !targetUid || !currentUserProfile || !profile) return;
    setUpdatingProfile(true);

    try {
      const reqId = `${currentUid}_${targetUid}`;
      const requestPayload: FriendRequest = {
        id: reqId,
        senderId: currentUid,
        senderName: currentUserProfile.name,
        senderPhoto: currentUserProfile.photoURL,
        senderUsername: currentUserProfile.username,
        receiverId: targetUid,
        status: 'pending',
        createdAt: new Date()
      };

      await setDoc(doc(db, 'friendRequests', reqId), requestPayload);

      // Create Notification for target user
      const notId = `${currentUid}_request_${Date.now()}`;
      await setDoc(doc(db, 'users', targetUid, 'notifications', notId), {
        id: notId,
        actorId: currentUid,
        actorName: currentUserProfile.name,
        actorPhotoURL: currentUserProfile.photoURL,
        type: 'friend_request',
        text: 'sent you a friend connection request',
        isRead: false,
        createdAt: new Date()
      });

    } catch (err) {
      console.error(err);
    } finally {
      setUpdatingProfile(false);
    }
  };

  const handleAcceptFriendRequest = async () => {
    if (!currentUid || !targetUid || !currentUserProfile || !profile || !friendRequest) return;
    setUpdatingProfile(true);

    try {
      const reqRef = doc(db, 'friendRequests', friendRequest.id);
      await updateDoc(reqRef, { status: 'accepted' });

      // Create connections in both users' friends subcollection to easily track count
      const refOwn = doc(db, 'users', currentUid, 'friends', targetUid);
      const refOther = doc(db, 'users', targetUid, 'friends', currentUid);

      await setDoc(refOwn, { uid: targetUid, name: profile.name, photoURL: profile.photoURL, username: profile.username });
      await setDoc(refOther, { uid: currentUid, name: currentUserProfile.name, photoURL: currentUserProfile.photoURL, username: currentUserProfile.username });

      // Update mutual friendsCount in metadata
      await updateDoc(doc(db, 'users', currentUid), { friendsCount: (currentUserProfile.friendsCount || 0) + 1 });
      await updateDoc(doc(db, 'users', targetUid), { friendsCount: (profile.friendsCount || 0) + 1 });

      // Create Notification for sender
      const notId = `${currentUid}_friend_accept_${Date.now()}`;
      await setDoc(doc(db, 'users', targetUid, 'notifications', notId), {
        id: notId,
        actorId: currentUid,
        actorName: currentUserProfile.name,
        actorPhotoURL: currentUserProfile.photoURL,
        type: 'friend_accept',
        text: 'accepted your friend connection request',
        isRead: false,
        createdAt: new Date()
      });

      setIsFriend(true);
    } catch (err) {
      console.error(err);
    } finally {
      setUpdatingProfile(false);
    }
  };

  const handleDeclineFriendRequest = async () => {
    if (!currentUid || !targetUid || !friendRequest) return;
    setUpdatingProfile(true);
    try {
      const reqRef = doc(db, 'friendRequests', friendRequest.id);
      await deleteDoc(reqRef);
    } catch (err) {
      console.error('Failed to decline friend request:', err);
    } finally {
      setUpdatingProfile(false);
    }
  };

  const handleCancelFriendRequest = async () => {
    if (!currentUid || !targetUid || !friendRequest) return;
    setUpdatingProfile(true);
    try {
      const reqRef = doc(db, 'friendRequests', friendRequest.id);
      await deleteDoc(reqRef);
    } catch (err) {
      console.error('Failed to cancel friend request:', err);
    } finally {
      setUpdatingProfile(false);
    }
  };

  const handleUnfriend = async () => {
    if (!currentUid || !targetUid || !profile || !currentUserProfile) return;
    if (!window.confirm(`Are you sure you want to unfriend ${profile.name}?`)) return;
    setUpdatingProfile(true);

    try {
      // 1. Delete friends connections in both users' subcollections
      const refOwn = doc(db, 'users', currentUid, 'friends', targetUid);
      const refOther = doc(db, 'users', targetUid, 'friends', currentUid);
      await deleteDoc(refOwn);
      await deleteDoc(refOther);

      // 2. Delete any friendRequest documents to ensure clean state
      const reqId1 = `${currentUid}_${targetUid}`;
      const reqId2 = `${targetUid}_${currentUid}`;
      await deleteDoc(doc(db, 'friendRequests', reqId1));
      await deleteDoc(doc(db, 'friendRequests', reqId2));

      // 3. Decrement mutual friends count using atomics
      await updateDoc(doc(db, 'users', currentUid), { friendsCount: increment(-1) });
      await updateDoc(doc(db, 'users', targetUid), { friendsCount: increment(-1) });
    } catch (err) {
      console.error('Failed to unfriend:', err);
    } finally {
      setUpdatingProfile(false);
    }
  };

  const handleLogout = () => {
    signOut(auth);
  };

  const handleBlockUser = async () => {
    if (!currentUid || !targetUid || !profile || !currentUserProfile) return;
    if (!window.confirm(`Are you sure you want to block ${profile.name}?`)) return;
    setUpdatingProfile(true);

    try {
      // 1. If currently friends, unfriend automatically
      if (isFriend) {
        const refOwn = doc(db, 'users', currentUid, 'friends', targetUid);
        const refOther = doc(db, 'users', targetUid, 'friends', currentUid);
        await deleteDoc(refOwn);
        await deleteDoc(refOther);

        // Decrement friends count
        await updateDoc(doc(db, 'users', currentUid), { friendsCount: increment(-1) });
        await updateDoc(doc(db, 'users', targetUid), { friendsCount: increment(-1) });
      }

      // 2. Delete any friend requests between them
      const reqId1 = `${currentUid}_${targetUid}`;
      const reqId2 = `${targetUid}_${currentUid}`;
      await deleteDoc(doc(db, 'friendRequests', reqId1));
      await deleteDoc(doc(db, 'friendRequests', reqId2));

      // 3. Add to blocks collection
      const blockId = `${currentUid}_${targetUid}`;
      await setDoc(doc(db, 'blocks', blockId), {
        id: blockId,
        blockerId: currentUid,
        blockerName: currentUserProfile.name,
        blockerUsername: currentUserProfile.username,
        blockerPhoto: currentUserProfile.photoURL,
        blockedId: targetUid,
        blockedName: profile.name,
        blockedUsername: profile.username,
        blockedPhoto: profile.photoURL,
        createdAt: new Date()
      });
      setIsFriend(false);
      setFriendRequest(null);
    } catch (err) {
      console.error('Failed to block user:', err);
    } finally {
      setUpdatingProfile(false);
    }
  };

  const handleUnblockUser = async (blockedIdToUnblock?: string) => {
    const idToUnblock = blockedIdToUnblock || targetUid;
    if (!currentUid || !idToUnblock) return;
    setUpdatingProfile(true);

    try {
      const blockId = `${currentUid}_${idToUnblock}`;
      await deleteDoc(doc(db, 'blocks', blockId));
    } catch (err) {
      console.error('Failed to unblock user:', err);
    } finally {
      setUpdatingProfile(false);
    }
  };

  const videoPosts = posts.filter(p => p.videoURL && p.videoURL.trim().length > 0);

  const isBlockedByMe = !isOwnProfile && targetUid && blockedUserIds.includes(targetUid) && myBlockedUsers.some(b => b.blockedId === targetUid);
  const blockedMe = !isOwnProfile && targetUid && blockedUserIds.includes(targetUid) && !myBlockedUsers.some(b => b.blockedId === targetUid);

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-4" id="profile_loading_pane">
        <span className="w-8 h-8 rounded-full border-4 border-blue-500 border-t-transparent animate-spin"></span>
        <span className="text-slate-450 text-xs font-bold mt-2">Loading profile metadata...</span>
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center text-center p-4 select-none" id="profile_missing_prompt">
        <div className="text-slate-400 text-sm font-bold">Profile metadata not found in database.</div>
      </div>
    );
  }

  if (!isOwnProfile && (isBlockedByMe || blockedMe)) {
    return (
      <div className="min-h-screen bg-slate-50 pb-20 font-sans select-none" id="profile_view_root">
        <div className="bg-white border-b border-slate-100 p-6 pt-10 text-center space-y-4 shadow-sm">
          <div className="relative w-24 h-24 mx-auto select-none">
            <div className="w-full h-full rounded-full border-4 border-slate-100 overflow-hidden bg-slate-100 relative flex items-center justify-center">
              <User className="w-10 h-10 text-slate-300" />
              <div className="absolute inset-0 bg-slate-900/40 flex items-center justify-center">
                <ShieldAlert className="w-8 h-8 text-white stroke-[2.2]" />
              </div>
            </div>
          </div>

          <div>
            <h2 className="text-xl font-extrabold text-slate-900 tracking-tight leading-snug">
              {isBlockedByMe ? profile.name : "Unavailable Profile"}
            </h2>
            <p className="text-slate-400 text-xs mt-0.5 font-bold">
              {isBlockedByMe ? `@${profile.username}` : "@private_user"}
            </p>
          </div>

          <div className="max-w-sm mx-auto pt-4 text-center">
            {isBlockedByMe ? (
              <div className="space-y-4">
                <p className="text-xs text-slate-500 font-medium leading-relaxed">
                  You blocked this user. Unblock them to view their posts, friends, and send messages.
                </p>
                <button
                  onClick={() => handleUnblockUser()}
                  disabled={updatingProfile}
                  className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 active:scale-95 text-white rounded-xl text-xs font-bold transition cursor-pointer shadow-lg shadow-blue-100"
                >
                  {updatingProfile ? 'Unblocking...' : 'Unblock User'}
                </button>
              </div>
            ) : (
              <p className="text-xs text-slate-500 font-medium leading-relaxed py-4">
                This account is private or profile is currently unavailable.
              </p>
            )}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 pb-20 font-sans select-none" id="profile_view_root">
      
      {/* Edit Overlay Form */}
      {isEditing && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 select-none" id="edit_profile_overlay">
          <motion.div
            initial={{ y: '100%' }}
            animate={{ y: 0 }}
            className="bg-white rounded-t-3xl sm:rounded-3xl w-full max-w-md p-5 border border-slate-100 flex flex-col max-h-[92vh] shadow-2xl"
          >
            <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-4">
              <span className="font-bold text-slate-800 text-sm">Edit Profile</span>
              <button
                id="edit_close_btn"
                onClick={() => setIsEditing(false)}
                className="text-xs font-bold text-slate-500 hover:text-slate-700 cursor-pointer"
              >
                Cancel
              </button>
            </div>

            <form onSubmit={handleSaveProfileChanges} className="space-y-4 overflow-y-auto max-h-[70vh] pr-1">
              {/* Picture Update */}
              <div className="flex flex-col items-center justify-center">
                <div className="relative">
                  <div className="w-20 h-20 rounded-full border border-slate-200 overflow-hidden bg-slate-100 shadow-inner flex items-center justify-center">
                    {editAvatarPreview ? (
                      <img src={editAvatarPreview} alt="Preview" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                    ) : (
                      <User className="w-8 h-8 text-slate-400" />
                    )}
                  </div>
                  <label className="absolute bottom-0 right-0 p-1.5 bg-blue-600 rounded-full text-white cursor-pointer hover:bg-blue-700 shadow shadow-blue-500/10">
                    <Camera className="w-3.5 h-3.5" />
                    <input type="file" accept="image/*" onChange={handleAvatarChange} className="hidden" />
                  </label>
                </div>
              </div>

              {/* Name */}
              <div>
                <label className="block text-slate-600 text-[10px] font-bold uppercase tracking-wider mb-1.5">Display Name</label>
                <input
                  id="edit_input_name"
                  type="text"
                  required
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-250 px-3 py-2 rounded-xl text-xs text-slate-900 outline-none focus:bg-white focus:border-blue-500 transition"
                />
              </div>

              {/* Username */}
              <div>
                <label className="block text-slate-600 text-[10px] font-bold uppercase tracking-wider mb-1.5">Unique Username</label>
                <div className="relative">
                  <input
                    id="edit_input_username"
                    type="text"
                    required
                    value={editUsername}
                    onChange={(e) => handleUsernameVerification(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-250 pl-3 pr-10 py-2 rounded-xl text-xs text-slate-900 outline-none focus:bg-white focus:border-blue-500 transition"
                  />
                  <span className="absolute inset-y-0 right-0 flex items-center pr-3">
                    {checkingUsername && <span className="w-3.5 h-3.5 rounded-full border-2 border-blue-500 border-t-transparent animate-spin"></span>}
                    {!checkingUsername && usernameStatus === 'available' && <CheckCircle className="w-3.5 h-3.5 text-emerald-500" />}
                  </span>
                </div>
                {usernameStatus === 'taken' && <p className="text-rose-500 text-[10px] mt-1">Username is taken.</p>}
                {usernameStatus === 'reserved' && <p className="text-rose-500 text-[10px] mt-1">Reserved name.</p>}
              </div>

              {/* Birthdate & Gender dropdowns */}
              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-slate-600 text-[10px] font-bold uppercase tracking-wider mb-1.5">Birthdate</label>
                  <input
                    id="edit_input_dob"
                    type="date"
                    required
                    value={editDob}
                    onChange={(e) => setEditDob(e.target.value)}
                    className="w-full bg-slate-55 border px-3 py-2 rounded-xl text-xs text-slate-900 outline-none focus:bg-white focus:border-blue-500 transition"
                  />
                </div>

                <div>
                  <label className="block text-slate-600 text-[10px] font-bold uppercase tracking-wider mb-1.5">Gender</label>
                  <select
                    id="edit_input_gender"
                    value={editGender}
                    onChange={(e) => setEditGender(e.target.value)}
                    className="w-full bg-slate-55 border px-3 py-2 rounded-xl text-xs text-slate-900 outline-none focus:bg-white focus:border-blue-500 transition cursor-pointer"
                  >
                    <option value="rather-not-say">Prefer not to say</option>
                    <option value="male">Male</option>
                    <option value="female">Female</option>
                    <option value="other">Other</option>
                  </select>
                </div>
              </div>

              {errorMsg && (
                <div className="p-2 bg-rose-50 border border-rose-100 rounded-xl flex items-center gap-1.5 text-rose-750 text-[10px]">
                  <ShieldAlert className="w-4 h-4 shrink-0" />
                  <span>{errorMsg}</span>
                </div>
              )}

              <button
                id="edit_save_btn"
                type="submit"
                disabled={updatingProfile || checkingUsername || usernameStatus === 'taken' || usernameStatus === 'reserved'}
                className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 transition text-white font-bold text-xs rounded-xl"
              >
                {updatingProfile ? 'Saving updates...' : 'Save Profile Changes'}
              </button>
            </form>
          </motion.div>
        </div>
      )}

      {/* Main Profile Header Info card */}
      <div className="bg-white border-b border-slate-100 p-5 pt-7 text-center space-y-4 shadow-sm" id="profile_hero_specs">
        {/* Profile Avatar circle */}
        <div className="relative w-24 h-24 mx-auto select-none">
          <div className="w-full h-full rounded-full border-4 border-slate-50 overflow-hidden bg-slate-100 shadow shadow-slate-100">
            <img src={profile.photoURL || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&h=150'} alt={profile.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
          </div>
        </div>

        {/* User Details */}
        <div>
          <h2 className="text-xl font-extrabold text-slate-900 tracking-tight leading-snug">{profile.name}</h2>
          <p className="text-slate-400 text-xs mt-0.5 font-bold">@{profile.username}</p>
        </div>

        {/* Profile Stats display */}
        <div className="flex justify-center divide-x divide-slate-100 font-bold text-xs text-slate-700 py-1" id="profile_meta_grid">
          <div className="px-5">
            <div className="text-slate-900 text-sm font-black">{posts.length}</div>
            <div className="text-[10px] text-slate-400 font-bold mt-0.5">Posts</div>
          </div>
          <div className="px-5">
            <div className="text-slate-900 text-sm font-black">{profile.friendsCount || 0}</div>
            <div className="text-[10px] text-slate-400 font-bold mt-0.5">Friends</div>
          </div>
          {isOwnProfile && (
            <div className="px-5">
              <div className="text-slate-900 text-xs font-semibold leading-relaxed mt-0.5">
                {profile.gender === 'male' ? 'Male' : profile.gender === 'female' ? 'Female' : 'Secret'}
              </div>
              <div className="text-[10px] text-slate-400 mt-0.5">Gender</div>
            </div>
          )}
        </div>

        {/* Actions Button Belt */}
        <div className="max-w-xs mx-auto flex gap-2.5 pt-2" id="profile_action_belt">
          {isOwnProfile ? (
            <>
              <button
                id="edit_profile_trigger"
                onClick={() => setIsEditing(true)}
                className="flex-1 py-2.5 px-4 bg-slate-100 hover:bg-slate-200 active:scale-98 transition text-slate-700 text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Edit className="w-4 h-4" />
                <span>Edit Profile</span>
              </button>
              <button
                id="profile_logout_btn"
                onClick={handleLogout}
                className="p-2.5 bg-rose-50 hover:bg-rose-100 text-rose-600 rounded-xl hover:text-rose-700 transition cursor-pointer"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </>
          ) : (
            <>
              {/* Direct Message trigger */}
              <button
                id="profile_chat_entry_btn"
                onClick={() => onStartChat(targetUid)}
                className="flex-grow py-2.5 bg-blue-600 hover:bg-blue-700 active:scale-98 text-white rounded-xl text-xs font-semibold shadow shadow-blue-500/10 cursor-pointer"
              >
                Send Message
              </button>

              {/* Friendship logic buttons status */}
              {isFriend ? (
                <button
                  id="unfriend_btn"
                  onClick={handleUnfriend}
                  disabled={updatingProfile}
                  className="px-4 py-2 bg-rose-50 hover:bg-rose-100 text-rose-600 border border-rose-100 text-xs font-bold rounded-xl flex items-center gap-1.5 shadow-sm transition active:scale-98 cursor-pointer"
                >
                  <UserMinus className="w-4 h-4" />
                  <span>Unfriend</span>
                </button>
              ) : friendRequest?.status === 'pending' && friendRequest.senderId === currentUid ? (
                <button
                  id="cancel_friend_request_btn"
                  onClick={handleCancelFriendRequest}
                  disabled={updatingProfile}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-250 text-slate-600 text-xs font-bold rounded-xl flex items-center gap-1.5 shadow-sm transition active:scale-98 cursor-pointer"
                >
                  <UserMinus className="w-4 h-4" />
                  <span>Cancel Request</span>
                </button>
              ) : friendRequest?.status === 'pending' && friendRequest.receiverId === currentUid ? (
                <div className="flex gap-2 shrink-0">
                  <button
                    id="accept_friend_request_btn"
                    onClick={handleAcceptFriendRequest}
                    disabled={updatingProfile}
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl flex items-center gap-1.2 cursor-pointer transition active:scale-98"
                  >
                    <UserPlus className="w-4 h-4" />
                    <span>Accept</span>
                  </button>
                  <button
                    id="decline_friend_request_btn"
                    onClick={handleDeclineFriendRequest}
                    disabled={updatingProfile}
                    className="px-4 py-2 bg-rose-50 hover:bg-rose-100 text-rose-600 text-xs font-bold rounded-xl flex items-center gap-1.2 cursor-pointer transition active:scale-98"
                  >
                    <UserMinus className="w-4 h-4" />
                    <span>Decline</span>
                  </button>
                </div>
              ) : (
                <button
                  id="send_friend_request_btn"
                  onClick={handleSendFriendRequest}
                  disabled={updatingProfile}
                  className="px-4 py-2 bg-blue-50 hover:bg-blue-100 text-blue-600 text-xs font-bold rounded-xl flex items-center gap-1.2 cursor-pointer transition active:scale-98"
                >
                  <UserPlus className="w-4 h-4" />
                  <span>Add Friend</span>
                </button>
              )}
              {/* Block action button */}
              <button
                id="profile_block_user_btn"
                onClick={handleBlockUser}
                disabled={updatingProfile}
                className="p-2.5 bg-rose-50 hover:bg-rose-100 text-rose-600 rounded-xl hover:text-rose-700 transition cursor-pointer flex items-center justify-center shrink-0 shadow-sm"
                title="Block user"
              >
                <ShieldAlert className="w-4 h-4" />
              </button>
            </>
          )}
        </div>
      </div>

      {/* Tabs navigation list: Posts, Stories, Videos, Friends */}
      <div className="sticky top-0 bg-white border-b border-slate-100 flex items-center justify-around z-10" id="profile_tabs_bar">
        {(isOwnProfile 
          ? (['posts', 'stories', 'videos', 'friends', 'blocked', 'earnings'] as const) 
          : (['posts', 'stories', 'videos', 'friends'] as const)
        ).map((tab) => (
          <button
            key={tab}
            id={`profile_tab_${tab}`}
            onClick={() => setActiveTab(tab)}
            className={`py-3.5 relative flex-1 text-center font-bold text-xs uppercase tracking-wider cursor-pointer ${
              activeTab === tab ? 'text-blue-600' : 'text-slate-450 hover:text-slate-600'
            }`}
          >
            <span>{tab}</span>
            {activeTab === tab && (
              <motion.div
                layoutId="profileActiveTabLine"
                className="absolute bottom-0 inset-x-5 h-0.75 bg-blue-600 rounded-full"
              />
            )}
          </button>
        ))}
      </div>

      {/* Tab Panels Contents */}
      <main className="max-w-md lg:max-w-2xl mx-auto p-4" id="profile_tab_panels">
        {activeTab === 'posts' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5" id="profile_posts_panel">
            {posts.length === 0 ? (
              <div className="text-center py-16 text-slate-400 bg-white border border-slate-100 rounded-3xl" id="profile_empty_posts">
                <FileText className="w-10 h-10 text-slate-200 mx-auto mb-2 stroke-[1.2]" />
                <blockquote className="font-bold text-xs text-slate-700">No posts shared yet</blockquote>
              </div>
            ) : (
              posts.map((post) => (
                <div
                  key={post.id}
                  id={`profile_p_${post.id}`}
                  onClick={() => onSelectPost(post.id)}
                  className="bg-white rounded-2xl border border-slate-100 p-4 hover:shadow-md transition cursor-pointer flex flex-col gap-2 relative shadow-inner"
                >
                  {post.content && (
                    <p className="text-slate-800 text-xs leading-relaxed line-clamp-3 whitespace-pre-wrap break-words">{post.content}</p>
                  )}
                  {post.imageURL && (
                    <div className="w-full h-40 rounded-xl overflow-hidden bg-slate-50 border border-slate-100 mt-1">
                      <img src={post.imageURL} alt="content thumbnail" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                    </div>
                  )}
                  <div className="flex items-center gap-4 text-[10px] text-slate-400 mt-2 font-bold px-1.5">
                    <span>{post.likesCount} Likes</span>
                    <span>{post.commentsCount} Comments</span>
                  </div>
                </div>
              ))
            )}
          </div>
        )}

        {activeTab === 'stories' && (
          <div className="grid grid-cols-3 gap-2.5" id="profile_stories_panel">
            {stories.length === 0 ? (
              <div className="col-span-3 text-center py-16 text-slate-400 bg-white border rounded-3xl p-6" id="profile_empty_stories">
                <Image className="w-10 h-10 text-slate-200 mx-auto mb-2 stroke-[1.2]" />
                <blockquote className="font-bold text-xs text-slate-700">No active stories</blockquote>
                <p className="text-[10px] mt-1 max-w-[180px] mx-auto">Stories expire and disappear automatically after 24h.</p>
              </div>
            ) : (
              stories.map((story) => (
                <div
                  key={story.id}
                  id={`profile_story_${story.id}`}
                  className="aspect-[3/4] bg-slate-100 rounded-2xl border border-slate-100 overflow-hidden relative shadow-inner group"
                >
                  <img src={story.imageURL} alt="story thumbnail" className="w-full h-full object-cover transition duration-300 group-hover:scale-103" referrerPolicy="no-referrer" />
                  <div className="absolute bottom-2 left-2 right-2 text-white font-bold text-[9px] bg-black/40 px-1.5 py-0.5 rounded truncate select-none">
                    Active Story
                  </div>
                </div>
              ))
            )}
          </div>
        )}

        {activeTab === 'videos' && (
          <div className="space-y-4" id="profile_videos_panel">
            {videoPosts.length === 0 ? (
              <div className="text-center py-16 text-slate-400 bg-white border border-slate-100 rounded-3xl" id="profile_empty_videos">
                <Video className="w-10 h-10 text-slate-200 mx-auto mb-2 stroke-[1.2]" />
                <blockquote className="font-bold text-xs text-slate-700">No video reels matching</blockquote>
              </div>
            ) : (
              videoPosts.map((post) => (
                <div
                  key={post.id}
                  id={`profile_vid_${post.id}`}
                  onClick={() => onSelectPost(post.id)}
                  className="bg-white rounded-2xl border border-slate-100 p-4 cursor-pointer hover:shadow-md transition flex flex-col gap-2.5"
                >
                  <span className="font-bold text-slate-800 text-xs line-clamp-1">{post.content || 'Video Attachment'}</span>
                  <div className="w-full h-44 rounded-xl overflow-hidden bg-black/90 shadow-inner shrink-0 relative">
                    {/* Display standard video graphic or similar */}
                    <div className="absolute inset-0 flex items-center justify-center bg-black/15 z-10 pointer-events-none">
                      <span className="p-2.5 bg-blue-600/90 text-white rounded-full font-bold text-[9px] shadow-sm tracking-wider uppercase">Active Reel</span>
                    </div>
                    <iframe
                      src={post.videoURL?.replace('/view', '/preview').replace('/edit', '/preview')}
                      title="video preview"
                      className="w-full h-full border-none opacity-80 pointer-events-none"
                    />
                  </div>
                </div>
              ))
            )}
          </div>
        )}

        {activeTab === 'friends' && (
          <div className="space-y-3" id="profile_friends_panel">
            {loadingFriends ? (
              <div className="flex flex-col items-center justify-center py-10 text-slate-400 gap-1.5" id="friends_tab_loading">
                <span className="w-5 h-5 block rounded-full border-2 border-blue-500 border-t-transparent animate-spin"></span>
                <span className="text-[10px] font-semibold text-slate-450">Loading friends...</span>
              </div>
            ) : friendsList.length === 0 ? (
              <div className="text-center py-16 text-slate-400 bg-white border border-slate-100 rounded-3xl p-6" id="profile_empty_friends">
                <Users className="w-10 h-10 text-slate-200 mx-auto mb-2 stroke-[1.2]" />
                <blockquote className="font-bold text-xs text-slate-700 font-sans">No friends connected yet</blockquote>
                <p className="text-[10px] mt-1 text-slate-400 max-w-[200px] mx-auto leading-normal">Connect with other social users to grow friendships.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3" id="friends_grid">
                {friendsList.map((friend) => (
                  <div
                    key={friend.id}
                    onClick={() => onSelectUser(friend.uid)}
                    className="flex items-center justify-between p-3 bg-white rounded-2xl border border-slate-100 shadow-sm hover:shadow transition duration-200 cursor-pointer"
                  >
                    <div className="flex items-center space-x-3 min-w-0">
                      <div className="w-10 h-10 rounded-full border border-slate-100 overflow-hidden bg-slate-50 shrink-0">
                        <img
                          src={friend.photoURL || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&h=150'}
                          alt={friend.name}
                          className="w-full h-full object-cover"
                          referrerPolicy="no-referrer"
                        />
                      </div>
                      <div className="truncate text-left leading-tight">
                        <h4 className="font-bold text-xs text-slate-800 truncate">{friend.name}</h4>
                        <p className="text-[10px] text-slate-400 truncate mt-0.5">@{friend.username}</p>
                      </div>
                    </div>
                    {/* If viewing own profile, show a dynamic quick-remove button */}
                    {isOwnProfile && (
                      <button
                        onClick={async (e) => {
                          e.stopPropagation();
                          if (window.confirm(`Are you sure you want to unfriend ${friend.name}?`)) {
                            try {
                              const refOwn = doc(db, 'users', currentUid, 'friends', friend.uid);
                              const refOther = doc(db, 'users', friend.uid, 'friends', currentUid);
                              await deleteDoc(refOwn);
                              await deleteDoc(refOther);
                              
                              const reqId1 = `${currentUid}_${friend.uid}`;
                              const reqId2 = `${friend.uid}_${currentUid}`;
                              await deleteDoc(doc(db, 'friendRequests', reqId1));
                              await deleteDoc(doc(db, 'friendRequests', reqId2));

                              await updateDoc(doc(db, 'users', currentUid), { friendsCount: increment(-1) });
                              await updateDoc(doc(db, 'users', friend.uid), { friendsCount: increment(-1) });
                            } catch (err) {
                              console.error('Failed to unfriend:', err);
                            }
                          }
                        }}
                        className="p-1.5 px-2.5 bg-rose-50 hover:bg-rose-100 text-rose-600 rounded-lg text-[9px] font-bold cursor-pointer transition flex items-center gap-1 select-none shrink-0"
                        title="Unfriend connection"
                      >
                        <UserMinus className="w-3 h-3" />
                        <span>Remove</span>
                      </button>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
        {activeTab === 'blocked' && isOwnProfile && (
          <div className="space-y-3" id="profile_blocked_panel">
            {myBlockedUsers.length === 0 ? (
              <div className="text-center py-16 text-slate-400 bg-white border border-slate-100 rounded-3xl p-6" id="profile_empty_blocked">
                <ShieldAlert className="w-10 h-10 text-slate-200 mx-auto mb-2 stroke-[1.2]" />
                <blockquote className="font-bold text-xs text-slate-700 font-sans">No blocked users</blockquote>
                <p className="text-[10px] mt-1 text-slate-400 max-w-[200px] mx-auto leading-normal">Users you block will appear here. You can unblock them at any time.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3" id="blocked_grid">
                {myBlockedUsers.map((blockedUser) => (
                  <div
                    key={blockedUser.id}
                    className="flex items-center justify-between p-3 bg-white rounded-2xl border border-slate-100 shadow-sm"
                  >
                    <div className="flex items-center space-x-3 min-w-0">
                      <div className="w-10 h-10 rounded-full border border-slate-100 overflow-hidden bg-slate-50 shrink-0">
                        <img
                          src={blockedUser.blockedPhoto || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&h=150'}
                          alt={blockedUser.blockedName}
                          className="w-full h-full object-cover"
                          referrerPolicy="no-referrer"
                        />
                      </div>
                      <div className="truncate text-left leading-tight">
                        <h4 className="font-bold text-xs text-slate-800 truncate">{blockedUser.blockedName}</h4>
                        <p className="text-[10px] text-slate-450 truncate mt-0.5">@{blockedUser.blockedUsername}</p>
                      </div>
                    </div>
                    <button
                      onClick={() => handleUnblockUser(blockedUser.blockedId)}
                      className="p-1.5 px-3 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-lg text-[9px] font-bold cursor-pointer transition select-none shrink-0"
                    >
                      Unblock
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  );
}
